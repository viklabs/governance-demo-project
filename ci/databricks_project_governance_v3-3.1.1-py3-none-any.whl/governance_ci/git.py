from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Sequence

from app.governance import normalize_repository_uri, validate_source_revision


def _run(source_dir: Path, args: Sequence[str]) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=source_dir,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def current_revision(source_dir: Path) -> str:
    return validate_source_revision(_run(source_dir, ["rev-parse", "HEAD"]))


def remote_repository(source_dir: Path) -> str:
    return _run(source_dir, ["config", "--get", "remote.origin.url"])


def verify_checkout(
    source_dir: Path,
    *,
    expected_revision: str,
    expected_repository: str,
    supplied_repository: str = "",
) -> str:
    source_dir = source_dir.resolve()
    if not (source_dir / ".git").exists():
        raise RuntimeError(f"{source_dir} is not a Git checkout; exact revision verification is required.")
    dirty = _run(source_dir, ["status", "--porcelain", "--untracked-files=all"])
    if dirty:
        raise RuntimeError(
            "Git checkout contains uncommitted or untracked changes; "
            "the governed release must deploy exactly the committed source revision."
        )
    actual_revision = current_revision(source_dir)
    expected = validate_source_revision(expected_revision)
    if actual_revision != expected:
        raise RuntimeError(
            f"Checked-out Git revision {actual_revision} does not match release revision {expected}."
        )
    remote = supplied_repository.strip() or remote_repository(source_dir)
    actual_identity = normalize_repository_uri(remote)
    registered_identity = normalize_repository_uri(expected_repository)
    if actual_identity.repository_key != registered_identity.repository_key:
        raise RuntimeError(
            f"Git remote {actual_identity.canonical_uri} does not match registered repository "
            f"{registered_identity.canonical_uri}."
        )
    return actual_identity.canonical_uri
