from governance_ci.cli import app

app()
