from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from governance_ci.auth import Credentials


@dataclass(frozen=True)
class CommandResult:
    stdout: str
    stderr: str


class BundleRunner:
    def __init__(self, bundle_dir: Path, credentials: Credentials):
        self.bundle_dir = bundle_dir.resolve()
        self.credentials = credentials
        if not (self.bundle_dir / "databricks.yml").exists():
            raise RuntimeError(f"No databricks.yml found in {self.bundle_dir}.")

    @staticmethod
    def _variable_args(variables: Mapping[str, str]) -> list[str]:
        result: list[str] = []
        for key, value in variables.items():
            result.append(f"--var={key}={value}")
        return result

    def command(
        self,
        args: Sequence[str],
        *,
        cwd: Path | None = None,
        check: bool = True,
    ) -> CommandResult:
        result = subprocess.run(
            ["databricks", *args],
            cwd=cwd or self.bundle_dir,
            env=self.credentials.cli_environment(),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if check and result.returncode != 0:
            raise RuntimeError(
                f"databricks {' '.join(args)} failed ({result.returncode}):\n"
                f"{result.stderr.strip() or result.stdout.strip()}"
            )
        return CommandResult(result.stdout, result.stderr)

    def validate(self, target: str, variables: Mapping[str, str], *, cwd: Path | None = None) -> dict[str, Any]:
        result = self.command(
            ["bundle", "validate", "--output", "json", "-t", target, *self._variable_args(variables)],
            cwd=cwd,
        )
        try:
            value = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError("Databricks Bundle validation did not return JSON output.") from exc
        if not isinstance(value, dict):
            raise RuntimeError("Resolved Databricks Bundle output is not an object.")
        return value

    def deploy(self, target: str, variables: Mapping[str, str]) -> None:
        self.command(["bundle", "deploy", "-t", target, *self._variable_args(variables)])

    def run(self, target: str, resource_key: str, variables: Mapping[str, str]) -> str:
        result = self.command(
            ["bundle", "run", "-t", target, *self._variable_args(variables), resource_key]
        )
        return (result.stdout + "\n" + result.stderr).strip()

    def summary(self, target: str, variables: Mapping[str, str]) -> dict[str, Any]:
        result = self.command(
            ["bundle", "summary", "--output", "json", "-t", target, *self._variable_args(variables)]
        )
        try:
            value = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError("Databricks Bundle summary did not return JSON output.") from exc
        if not isinstance(value, dict):
            raise RuntimeError("Databricks Bundle summary output is not an object.")
        return value


def prepare_prod_preflight_copy(
    bundle_dir: Path,
    *,
    prod_target: str,
    validation_host: str,
) -> tempfile.TemporaryDirectory[str]:
    """Copy the Bundle and route prod target validation through the dev workspace.

    This resolves the complete production target, including production-mode requirements and
    variables, without granting the development CI identity production access. The production
    pipeline performs a second real validation in it-prod immediately before deployment.
    """

    temporary = tempfile.TemporaryDirectory(prefix="governance-prod-preflight-")
    destination = Path(temporary.name) / "bundle"
    shutil.copytree(
        bundle_dir,
        destination,
        symlinks=True,
        ignore=shutil.ignore_patterns(
            ".git",
            ".databricks",
            ".bundle",
            ".venv",
            "__pycache__",
            ".pytest_cache",
            ".ruff_cache",
            "*.pyc",
        ),
    )
    root_file = destination / "databricks.yml"
    data = yaml.safe_load(root_file.read_text(encoding="utf-8")) or {}
    targets = data.get("targets")
    if not isinstance(targets, dict) or prod_target not in targets:
        temporary.cleanup()
        raise RuntimeError(f"Bundle target {prod_target!r} is not defined.")
    target = targets[prod_target]
    if not isinstance(target, dict):
        temporary.cleanup()
        raise RuntimeError(f"Bundle target {prod_target!r} must be an object.")
    workspace = target.setdefault("workspace", {})
    if not isinstance(workspace, dict):
        temporary.cleanup()
        raise RuntimeError(f"Bundle target {prod_target!r} workspace must be an object.")
    workspace["host"] = validation_host.rstrip("/")
    root_file.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return temporary
