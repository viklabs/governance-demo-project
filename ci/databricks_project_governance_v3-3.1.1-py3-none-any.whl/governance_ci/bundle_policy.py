from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any


def nested_value(root: Mapping[str, Any], path: str) -> Any:
    value: Any = root
    for segment in path.split("."):
        if not isinstance(value, Mapping):
            return None
        value = value.get(segment)
    return value


def normalize_tags(value: Any) -> dict[str, str]:
    if isinstance(value, Mapping):
        return {str(key): str(item) for key, item in value.items()}
    if isinstance(value, list):
        result: dict[str, str] = {}
        for item in value:
            if not isinstance(item, Mapping):
                continue
            key = item.get("key") or item.get("name")
            if key is not None:
                result[str(key)] = str(item.get("value", ""))
        return result
    return {}


@dataclass(frozen=True)
class BundlePolicyResult:
    passed: bool
    failures: tuple[str, ...]
    resources: tuple[str, ...]

    @property
    def detail(self) -> str:
        return "; ".join(self.failures) if self.failures else f"Validated {len(self.resources)} Bundle resource(s)."


def validate_resolved_bundle(
    resolved: Mapping[str, Any],
    *,
    project_id: str,
    environment: str,
    project_tag_key: str = "project_tag",
    environment_tag_key: str = "environment",
    fail_on_unknown_resource_type: bool = True,
) -> BundlePolicyResult:
    expected = {
        project_tag_key: project_id,
        environment_tag_key: environment,
    }
    resources = resolved.get("resources") or {}
    failures: list[str] = []
    governed: list[str] = []
    native_paths = {"jobs": "tags", "pipelines": "tags"}
    managed_types = {"dashboards", "apps"}
    ignored_types = {"permissions"}
    if not isinstance(resources, Mapping):
        return BundlePolicyResult(False, ("Resolved Bundle resources must be a mapping.",), ())

    for resource_type_raw, collection in resources.items():
        resource_type = str(resource_type_raw)
        if not collection:
            continue
        if not isinstance(collection, Mapping):
            failures.append(f"{resource_type} must be a mapping of logical resources.")
            continue
        if resource_type in native_paths:
            for logical_name, config in collection.items():
                label = f"{resource_type}.{logical_name}"
                governed.append(label)
                if not isinstance(config, Mapping):
                    failures.append(f"{label} is not an object.")
                    continue
                actual = normalize_tags(nested_value(config, native_paths[resource_type]))
                missing = [f"{key}={value!r}" for key, value in expected.items() if actual.get(key) != value]
                if missing:
                    failures.append(f"{label} expected {', '.join(missing)}; got {actual!r}.")
            continue
        if resource_type in managed_types:
            governed.extend(f"{resource_type}.{name}" for name in collection)
            continue
        if resource_type in ignored_types:
            continue
        if fail_on_unknown_resource_type:
            failures.append(f"Unsupported non-empty Bundle resource type: {resource_type}.")

    return BundlePolicyResult(not failures, tuple(failures), tuple(governed))
