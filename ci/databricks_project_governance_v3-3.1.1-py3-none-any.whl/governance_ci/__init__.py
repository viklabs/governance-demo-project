"""Provider-neutral CI client for the simplified governance v3 App."""

__version__ = "3.1.1"
