from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Credentials:
    prefix: str
    host: str
    token: str = ""
    client_id: str = ""
    client_secret: str = ""
    profile: str = ""
    auth_type: str = ""

    @classmethod
    def from_environment(cls, prefix: str) -> "Credentials":
        """Load only environment-specific credentials.

        Generic DATABRICKS_* variables are deliberately ignored here. CI must explicitly use
        REGISTRY_DATABRICKS_*, DEV_DATABRICKS_*, or PROD_DATABRICKS_* so a development
        credential cannot be selected accidentally for a production command.
        """
        normalized = prefix.strip().upper()

        def value(name: str) -> str:
            return os.getenv(f"{normalized}_DATABRICKS_{name}", "").strip()

        return cls(
            prefix=normalized,
            host=value("HOST").rstrip("/"),
            token=value("TOKEN"),
            client_id=value("CLIENT_ID"),
            client_secret=value("CLIENT_SECRET"),
            profile=value("CONFIG_PROFILE"),
            auth_type=value("AUTH_TYPE"),
        )

    def validate(self) -> None:
        if not self.host and not self.profile:
            raise RuntimeError(
                f"{self.prefix}_DATABRICKS_HOST or {self.prefix}_DATABRICKS_CONFIG_PROFILE is required."
            )
        if not (self.profile or self.token or (self.client_id and self.client_secret)):
            raise RuntimeError(
                f"Configure {self.prefix} Databricks authentication with a profile, token, "
                "or OAuth client ID and secret."
            )

    def resolved_host(self) -> str:
        """Return the effective workspace host, including hosts loaded from a profile."""
        if self.host:
            return self.host
        host = str(getattr(self.workspace_client().config, "host", "") or "").strip().rstrip("/")
        if not host:
            raise RuntimeError(
                f"Unable to resolve a workspace host from {self.prefix}_DATABRICKS_CONFIG_PROFILE."
            )
        return host

    def workspace_client(self) -> Any:
        try:
            from databricks.sdk import WorkspaceClient
        except ImportError as exc:  # pragma: no cover - deployment dependency
            raise RuntimeError("databricks-sdk is required by governance-ci") from exc
        self.validate()
        kwargs: dict[str, Any] = {}
        if self.profile:
            kwargs["profile"] = self.profile
        if self.host:
            kwargs["host"] = self.host
        if self.token:
            kwargs["token"] = self.token
        if self.client_id:
            kwargs["client_id"] = self.client_id
        if self.client_secret:
            kwargs["client_secret"] = self.client_secret
        if self.auth_type:
            kwargs["auth_type"] = self.auth_type
        return WorkspaceClient(**kwargs)

    def cli_environment(self) -> dict[str, str]:
        """Return a clean unified-auth environment for a Databricks CLI subprocess."""
        self.validate()
        env = dict(os.environ)
        for key in tuple(env):
            if key.startswith("DATABRICKS_"):
                env.pop(key, None)
        if self.host:
            env["DATABRICKS_HOST"] = self.host
        if self.profile:
            env["DATABRICKS_CONFIG_PROFILE"] = self.profile
        if self.token:
            env["DATABRICKS_TOKEN"] = self.token
        if self.client_id:
            env["DATABRICKS_CLIENT_ID"] = self.client_id
        if self.client_secret:
            env["DATABRICKS_CLIENT_SECRET"] = self.client_secret
        if self.auth_type:
            env["DATABRICKS_AUTH_TYPE"] = self.auth_type
        return env
