from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Callable


def _as_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if hasattr(value, "as_dict"):
        result = value.as_dict()
        return result if isinstance(result, dict) else {}
    return {}


def _get(value: Any, *path: str) -> Any:
    current = value
    for key in path:
        if isinstance(current, Mapping):
            current = current.get(key)
        else:
            current = getattr(current, key, None)
        if current is None:
            return None
    return current


def _summary_resource(summary: Mapping[str, Any], resource_type: str, logical_name: str) -> Any:
    resources = summary.get("resources") or {}
    collection = resources.get(resource_type) or {}
    return collection.get(logical_name) or {} if isinstance(collection, Mapping) else {}


def _identifier(item: Any, *keys: str) -> str:
    data = _as_dict(item)
    for key in keys:
        value = data.get(key) if data else _get(item, key)
        if value not in (None, ""):
            return str(value)
    return ""


@dataclass(frozen=True)
class TagEngineResult:
    tag_results: tuple[dict[str, str], ...]
    failures: tuple[str, ...]
    resource_count: int

    @property
    def passed(self) -> bool:
        return (
            self.resource_count > 0
            and not self.failures
            and all(item["status"] in {"PASS", "MANAGED"} for item in self.tag_results)
        )


class TagEngine:
    """Apply/read mandatory tags after deployment and emit one evidence row per tag.

    Jobs and pipelines are source-owned and read-only here. Schemas, tables, views, volumes,
    dashboards, and Apps are platform-managed by the CI identity, then read back. An existing
    project tag belonging to another project is never overwritten.
    """

    def __init__(
        self,
        client: Any | None,
        *,
        project_tag_key: str = "project_tag",
        environment_tag_key: str = "environment",
        protect_existing_project_tag: bool = True,
        manage_platform_tags: bool = True,
        dry_run: bool = False,
    ):
        self.client = client
        self.project_tag_key = project_tag_key
        self.environment_tag_key = environment_tag_key
        self.protect_existing_project_tag = protect_existing_project_tag
        self.manage_platform_tags = manage_platform_tags
        self.dry_run = dry_run
        if client is None and not dry_run:
            raise ValueError("A Databricks WorkspaceClient is required.")

    @staticmethod
    def _tag_value(value: Any) -> str:
        return str(getattr(value, "tag_value", "") or _get(value, "tag_value") or "")

    def _protect(self, key: str, current: str, expected: str) -> None:
        if (
            key == self.project_tag_key
            and current
            and current != expected
            and self.protect_existing_project_tag
        ):
            raise RuntimeError(
                f"asset is already owned by project tag {current!r}; expected {expected!r}"
            )

    def _upsert_uc(self, entity_type: str, identifier: str, expected: Mapping[str, str]) -> dict[str, str]:
        if self.dry_run:
            return dict(expected)
        try:
            from databricks.sdk.service.catalog import EntityTagAssignment
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("databricks-sdk with Unity Catalog entity tags is required") from exc
        api = self.client.entity_tag_assignments
        existing = {
            str(getattr(item, "tag_key", "") or _get(item, "tag_key") or ""): item
            for item in api.list(entity_type=entity_type, entity_name=identifier)
        }
        actual: dict[str, str] = {}
        for key, value in expected.items():
            current = existing.get(key)
            current_value = self._tag_value(current) if current is not None else ""
            self._protect(key, current_value, value)
            assignment = EntityTagAssignment(
                entity_type=entity_type,
                entity_name=identifier,
                tag_key=key,
                tag_value=value,
            )
            if self.manage_platform_tags:
                if current is None:
                    api.create(assignment)
                elif current_value != value:
                    api.update(entity_type, identifier, key, assignment, "tag_value")
                verified = api.get(entity_type, identifier, key)
                actual[key] = self._tag_value(verified)
            else:
                actual[key] = current_value
        return actual

    def _upsert_workspace(
        self, entity_type: str, identifier: str, expected: Mapping[str, str]
    ) -> dict[str, str]:
        if self.dry_run:
            return dict(expected)
        try:
            from databricks.sdk.service.tags import TagAssignment
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("databricks-sdk with workspace entity tags is required") from exc
        api = getattr(self.client, "workspace_entity_tag_assignments", None)
        if api is None:
            raise RuntimeError("Workspace entity tag assignment API is unavailable.")
        existing = {
            str(getattr(item, "tag_key", "") or _get(item, "tag_key") or ""): item
            for item in api.list_tag_assignments(entity_type=entity_type, entity_id=identifier)
        }
        actual: dict[str, str] = {}
        for key, value in expected.items():
            current = existing.get(key)
            current_value = self._tag_value(current) if current is not None else ""
            self._protect(key, current_value, value)
            assignment = TagAssignment(
                entity_type=entity_type,
                entity_id=identifier,
                tag_key=key,
                tag_value=value,
            )
            if self.manage_platform_tags:
                if current is None:
                    api.create_tag_assignment(assignment)
                elif current_value != value:
                    api.update_tag_assignment(
                        entity_type, identifier, key, assignment, "tag_value"
                    )
                verified = api.get_tag_assignment(entity_type, identifier, key)
                actual[key] = self._tag_value(verified)
            else:
                actual[key] = current_value
        return actual

    def _native_tags(self, resource_type: str, identifier: str) -> dict[str, str]:
        if self.dry_run:
            return {}
        if resource_type == "jobs":
            value = self.client.jobs.get(int(identifier))
            tags = _get(value, "settings", "tags") or {}
        elif resource_type == "pipelines":
            value = self.client.pipelines.get(identifier)
            tags = _get(value, "spec", "tags") or _get(value, "tags") or {}
        else:
            raise RuntimeError(f"Unsupported native resource type: {resource_type}")
        return {str(key): str(item) for key, item in tags.items()}

    @staticmethod
    def _row(
        *,
        environment: str,
        resource_type: str,
        logical_name: str,
        identifier: str,
        tag_key: str,
        expected: str,
        actual: str,
        mode: str,
        status: str,
        detail: str,
    ) -> dict[str, str]:
        return {
            "environment": environment,
            "resource_type": resource_type,
            "logical_name": logical_name,
            "resource_identifier": identifier,
            "tag_key": tag_key,
            "expected_value": expected,
            "actual_value": actual,
            "verification_mode": mode,
            "status": status,
            "detail": detail,
        }

    def _record(
        self,
        results: list[dict[str, str]],
        failures: list[str],
        *,
        environment: str,
        resource_type: str,
        logical_name: str,
        identifier: str,
        expected: Mapping[str, str],
        mode: str,
        action: Callable[[], Mapping[str, str]],
        managed: bool,
        detail: str,
    ) -> None:
        try:
            actual = dict(action())
            for key, expected_value in expected.items():
                actual_value = str(actual.get(key, ""))
                matched = actual_value == expected_value
                status = "MANAGED" if managed and matched else "PASS" if matched else "FAIL"
                results.append(
                    self._row(
                        environment=environment,
                        resource_type=resource_type,
                        logical_name=logical_name,
                        identifier=identifier,
                        tag_key=key,
                        expected=expected_value,
                        actual=actual_value,
                        mode=mode,
                        status=status,
                        detail=detail,
                    )
                )
                if not matched:
                    failures.append(
                        f"{resource_type} {identifier} has {key}={actual_value!r}; "
                        f"expected {expected_value!r}."
                    )
        except Exception as exc:
            failures.append(f"{resource_type} {identifier}: {exc}")
            for key, expected_value in expected.items():
                results.append(
                    self._row(
                        environment=environment,
                        resource_type=resource_type,
                        logical_name=logical_name,
                        identifier=identifier,
                        tag_key=key,
                        expected=expected_value,
                        actual="",
                        mode=mode,
                        status="FAIL",
                        detail=str(exc),
                    )
                )

    def enforce(
        self,
        *,
        environment: str,
        resolved: Mapping[str, Any],
        summary: Mapping[str, Any],
        catalog: str,
        schema: str,
        additional_assets: list[Mapping[str, Any]] | tuple[Mapping[str, Any], ...],
        expected_tags: Mapping[str, str],
    ) -> TagEngineResult:
        results: list[dict[str, str]] = []
        failures: list[str] = []
        seen: set[tuple[str, str]] = set()
        resources = resolved.get("resources") or {}
        resource_count = 0

        def record_once(
            *,
            resource_type: str,
            logical_name: str,
            identifier: str,
            mode: str,
            action: Callable[[], Mapping[str, str]],
            managed: bool,
            detail: str,
        ) -> None:
            nonlocal resource_count
            key = (resource_type, identifier)
            if not identifier or key in seen:
                return
            seen.add(key)
            resource_count += 1
            self._record(
                results,
                failures,
                environment=environment,
                resource_type=resource_type,
                logical_name=logical_name or identifier.rsplit(".", 1)[-1],
                identifier=identifier,
                expected=expected_tags,
                mode=mode,
                action=action,
                managed=managed,
                detail=detail,
            )

        # Bundle-native resources: source declarations were checked before deploy; read back actual tags.
        for resource_type in ("jobs", "pipelines"):
            collection = resources.get(resource_type) or {}
            if not isinstance(collection, Mapping):
                continue
            for logical_name in collection:
                item = _summary_resource(summary, resource_type, str(logical_name))
                identifier = _identifier(
                    item,
                    "id",
                    "resource_id",
                    "job_id" if resource_type == "jobs" else "pipeline_id",
                )
                if not identifier:
                    identifier = f"{resource_type}.{logical_name}"
                    action = lambda: (_ for _ in ()).throw(
                        RuntimeError("Bundle summary did not expose the deployed resource ID.")
                    )
                elif self.dry_run:
                    tags = (collection.get(logical_name) or {}).get("tags") or {}
                    action = lambda tags=tags: {str(k): str(v) for k, v in tags.items()}
                else:
                    action = lambda rt=resource_type, ident=identifier: self._native_tags(rt, ident)
                record_once(
                    resource_type=resource_type,
                    logical_name=str(logical_name),
                    identifier=identifier,
                    mode="BUNDLE_SUMMARY_NATIVE_API_READBACK",
                    action=action,
                    managed=False,
                    detail="Native resource tags were read back from the deployed resource.",
                )

        # Bundle-managed workspace entities.
        for resource_type, entity_type in (("dashboards", "dashboards"), ("apps", "apps")):
            collection = resources.get(resource_type) or {}
            if not isinstance(collection, Mapping):
                continue
            for logical_name in collection:
                item = _summary_resource(summary, resource_type, str(logical_name))
                identifier = _identifier(item, "id", "resource_id", "dashboard_id", "name")
                if not identifier:
                    identifier = f"{resource_type}.{logical_name}"
                record_once(
                    resource_type=resource_type,
                    logical_name=str(logical_name),
                    identifier=identifier,
                    mode="WORKSPACE_ENTITY_TAG_API",
                    action=lambda et=entity_type, ident=identifier: self._upsert_workspace(
                        et, ident, expected_tags
                    ),
                    managed=True,
                    detail="System tags were assigned and read back through the workspace tag API.",
                )

        # Registered Unity Catalog project schema and every table/view/volume in it.
        schema_identifier = f"{catalog}.{schema}"
        record_once(
            resource_type="schemas",
            logical_name=schema,
            identifier=schema_identifier,
            mode="UNITY_CATALOG_TAG_API",
            action=lambda: self._upsert_uc("schemas", schema_identifier, expected_tags),
            managed=True,
            detail="Registered project schema was tagged and read back.",
        )
        tables = [] if self.dry_run else list(
            self.client.tables.list(catalog_name=catalog, schema_name=schema)
        )
        volumes = [] if self.dry_run else list(
            self.client.volumes.list(catalog_name=catalog, schema_name=schema)
        )
        for table in tables:
            identifier = str(_as_dict(table).get("full_name") or _get(table, "full_name") or "")
            if not identifier:
                continue
            table_type = str(
                _as_dict(table).get("table_type") or _get(table, "table_type") or ""
            ).upper()
            resource_type = "views" if "VIEW" in table_type else "tables"
            record_once(
                resource_type=resource_type,
                logical_name=identifier.rsplit(".", 1)[-1],
                identifier=identifier,
                mode="UNITY_CATALOG_TAG_API",
                action=lambda ident=identifier: self._upsert_uc("tables", ident, expected_tags),
                managed=True,
                detail="Runtime data asset was discovered, tagged, and read back.",
            )
        for volume in volumes:
            identifier = str(_as_dict(volume).get("full_name") or _get(volume, "full_name") or "")
            if not identifier:
                continue
            record_once(
                resource_type="volumes",
                logical_name=identifier.rsplit(".", 1)[-1],
                identifier=identifier,
                mode="UNITY_CATALOG_TAG_API",
                action=lambda ident=identifier: self._upsert_uc("volumes", ident, expected_tags),
                managed=True,
                detail="Volume was discovered, tagged, and read back.",
            )

        # Optional explicit assets outside the registered schema or not managed by the Bundle.
        type_map = {
            "job": "jobs",
            "pipeline": "pipelines",
            "dashboard": "dashboards",
            "app": "apps",
            "schema": "schemas",
            "table": "tables",
            "view": "views",
            "volume": "volumes",
        }
        for asset in additional_assets:
            asset_environment = str(asset.get("environment") or "both").strip().lower()
            if asset_environment not in {"both", environment}:
                continue
            raw_type = str(asset.get("resource_type") or "").lower()
            resource_type = type_map.get(raw_type, raw_type)
            identifier = str(asset.get("identifier") or "").strip()
            logical_name = str(asset.get("logical_name") or "").strip() or identifier.rsplit(".", 1)[-1]
            if resource_type in {"jobs", "pipelines"}:
                record_once(
                    resource_type=resource_type,
                    logical_name=logical_name,
                    identifier=identifier,
                    mode="EXPLICIT_NATIVE_API_READBACK",
                    action=lambda rt=resource_type, ident=identifier: self._native_tags(rt, ident),
                    managed=False,
                    detail="Explicit native resource tags were read back.",
                )
            elif resource_type in {"dashboards", "apps"}:
                record_once(
                    resource_type=resource_type,
                    logical_name=logical_name,
                    identifier=identifier,
                    mode="EXPLICIT_WORKSPACE_TAG_API",
                    action=lambda rt=resource_type, ident=identifier: self._upsert_workspace(
                        rt, ident, expected_tags
                    ),
                    managed=True,
                    detail="Explicit workspace resource was tagged and read back.",
                )
            elif resource_type in {"schemas", "tables", "views", "volumes"}:
                entity_type = "tables" if resource_type == "views" else resource_type
                record_once(
                    resource_type=resource_type,
                    logical_name=logical_name,
                    identifier=identifier,
                    mode="EXPLICIT_UNITY_CATALOG_TAG_API",
                    action=lambda et=entity_type, ident=identifier: self._upsert_uc(
                        et, ident, expected_tags
                    ),
                    managed=True,
                    detail="Explicit Unity Catalog resource was tagged and read back.",
                )
            else:
                failures.append(f"Additional asset type {raw_type!r} is unsupported.")

        return TagEngineResult(tuple(results), tuple(failures), resource_count)
