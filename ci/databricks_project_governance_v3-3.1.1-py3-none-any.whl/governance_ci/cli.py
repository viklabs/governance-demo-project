from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlsplit

import typer

from governance_ci.auth import Credentials
from governance_ci.bundle import BundleRunner, prepare_prod_preflight_copy
from governance_ci.bundle_policy import BundlePolicyResult, validate_resolved_bundle
from governance_ci.client import GovernanceAppClient
from governance_ci.git import current_revision, remote_repository, verify_checkout
from governance_ci.tags import TagEngine

app = typer.Typer(
    no_args_is_help=True,
    add_completion=False,
    help=(
        "Provider-neutral Databricks CI client for project lookup, exact-revision dev "
        "validation, tag evidence, approval authorization, and production deployment."
    ),
)


def _json(value: Any) -> None:
    typer.echo(json.dumps(value, indent=2, sort_keys=True, default=str))


def _app_url(value: str) -> str:
    resolved = value.strip() or os.getenv("GOVERNANCE_APP_URL", "").strip()
    if not resolved:
        raise typer.BadParameter("--app-url or GOVERNANCE_APP_URL is required.")
    return resolved.rstrip("/")


def _source_dir(value: Path) -> Path:
    resolved = value.expanduser().resolve()
    if not resolved.is_dir():
        raise typer.BadParameter(f"Source directory does not exist: {resolved}")
    return resolved


def _identity(source_dir: Path, repository_uri: str, source_revision: str) -> tuple[str, str]:
    revision = source_revision.strip() or current_revision(source_dir)
    repository = repository_uri.strip() or remote_repository(source_dir)
    return repository, revision


def _client(app_url: str) -> GovernanceAppClient:
    return GovernanceAppClient(app_url, Credentials.from_environment("REGISTRY"))


def _workspace_origin(value: str, label: str) -> tuple[str, str]:
    parsed = urlsplit(value.strip().rstrip("/"))
    if parsed.scheme.lower() not in {"https", "http"} or not parsed.hostname:
        raise RuntimeError(f"{label} must be a valid workspace HTTP(S) URL.")
    if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise RuntimeError(f"{label} must be the workspace root URL without a path, query, or fragment.")
    port = parsed.port or (443 if parsed.scheme.lower() == "https" else 80)
    return parsed.hostname.lower().rstrip("."), str(port)


def _assert_workspace_host(credentials: Credentials, expected_host: str, label: str) -> None:
    actual = credentials.resolved_host()
    if _workspace_origin(actual, f"{label} credential host") != _workspace_origin(
        expected_host, f"registered {label} host"
    ):
        raise RuntimeError(
            f"{label} credential resolves to {actual!r}, but the project is registered for "
            f"{expected_host!r}. Deployment to an unregistered workspace is blocked."
        )


def _workspace_variables(project: Mapping[str, Any], environment: str) -> dict[str, str]:
    if environment == "dev":
        return {
            "project_id": str(project["project_id"]),
            "environment_name": str(project["required_tags"]["dev"]["environment"]),
            "catalog_name": str(project["dev_catalog"]),
            "schema_name": str(project["dev_schema"]),
        }
    return {
        "project_id": str(project["project_id"]),
        "environment_name": str(project["required_tags"]["prod"]["environment"]),
        "catalog_name": str(project["prod_catalog"]),
        "schema_name": str(project["prod_schema"]),
    }


def _tag_contract(
    project: Mapping[str, Any], environment: str
) -> tuple[dict[str, str], str, str]:
    expected = {
        str(key): str(value)
        for key, value in dict(project["required_tags"][environment]).items()
    }
    project_id = str(project["project_id"])
    project_keys = [key for key, value in expected.items() if value == project_id]
    environment_keys = [key for key, value in expected.items() if value != project_id]
    if len(project_keys) != 1 or len(environment_keys) != 1:
        raise RuntimeError("The App returned an invalid mandatory tag contract.")
    return expected, project_keys[0], environment_keys[0]


def _policy_or_raise(
    resolved: Mapping[str, Any],
    *,
    project: Mapping[str, Any],
    environment: str,
) -> BundlePolicyResult:
    expected, project_tag_key, environment_tag_key = _tag_contract(project, environment)
    result = validate_resolved_bundle(
        resolved,
        project_id=str(project["project_id"]),
        environment=str(expected[environment_tag_key]),
        project_tag_key=project_tag_key,
        environment_tag_key=environment_tag_key,
    )
    if not result.passed:
        raise RuntimeError(result.detail)
    return result


def _run_validation_resources(
    runner: BundleRunner,
    *,
    target: str,
    variables: Mapping[str, str],
    resources: list[Mapping[str, Any]],
) -> list[str]:
    outputs: list[str] = []
    for item in resources:
        resource_type = str(item.get("type") or "").strip().lower()
        key = str(item.get("key") or "").strip()
        if resource_type not in {"job", "pipeline"} or not key:
            raise RuntimeError(f"Invalid configured validation resource: {item!r}")
        outputs.append(runner.run(target, key, variables))
    return outputs


def _detail(items: list[str]) -> str:
    compact = [item.strip() for item in items if item and item.strip()]
    return " | ".join(compact)[:12000]


def _write_result(path: Path | None, payload: Mapping[str, Any]) -> None:
    if path is None:
        return
    resolved = path.expanduser().resolve()
    resolved.parent.mkdir(parents=True, exist_ok=True)
    resolved.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


@app.command("project-info")
def project_info(
    project_id: str = typer.Option(..., help="App-generated project ID."),
    app_url: str = typer.Option("", help="Direct Databricks App URL."),
) -> None:
    """Return active project configuration and required tags for CI."""
    try:
        _json(_client(_app_url(app_url)).project_info(project_id))
    except Exception as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(2) from exc


@app.command("validate-release")
def validate_release(
    release_id: str = typer.Option(..., help="Release ID created in the App."),
    source_dir: Path = typer.Option(Path("."), exists=True, file_okay=False),
    repository_uri: str = typer.Option("", help="Repository URI; defaults to origin."),
    source_revision: str = typer.Option("", help="Full Git object ID; defaults to HEAD."),
    run_url: str = typer.Option("", help="CI run URL recorded with dev evidence."),
    result_file: Path | None = typer.Option(
        None, help="Optional JSON evidence file retained when App reporting fails."
    ),
    app_url: str = typer.Option("", help="Direct Databricks App URL."),
) -> None:
    """Validate and deploy an exact release in dev, then submit mandatory tag evidence."""
    client: GovernanceAppClient | None = None
    repository = ""
    revision = ""
    project: dict[str, Any] = {}
    flags = {
        "dev_bundle_valid": False,
        "prod_bundle_preflight_valid": False,
        "deployment_succeeded": False,
        "workload_succeeded": False,
    }
    details: list[str] = []
    tag_results: list[dict[str, str]] = []
    try:
        source = _source_dir(source_dir)
        repository, revision = _identity(source, repository_uri, source_revision)
        client = _client(_app_url(app_url))
        context = client.release_info(
            release_id, repository_uri=repository, source_revision=revision
        )
        project = dict(context["project"])
        verified_repository = verify_checkout(
            source,
            expected_revision=str(context["release"]["source_revision"]),
            expected_repository=str(project["repository_uri"]),
            supplied_repository=repository,
        )
        repository = verified_repository
        bundle_dir = (source / str(project["bundle_path"])).resolve()
        if source not in bundle_dir.parents and bundle_dir != source:
            raise RuntimeError("Registered bundle_path resolves outside the Git checkout.")

        credentials = Credentials.from_environment("DEV")
        _assert_workspace_host(credentials, str(project["dev_workspace_host"]), "development")
        runner = BundleRunner(bundle_dir, credentials)
        dev_variables = _workspace_variables(project, "dev")
        prod_variables = _workspace_variables(project, "prod")

        resolved_dev = runner.validate(str(project["dev_target"]), dev_variables)
        policy_dev = _policy_or_raise(resolved_dev, project=project, environment="dev")
        flags["dev_bundle_valid"] = True
        details.append(policy_dev.detail)

        temporary: tempfile.TemporaryDirectory[str] | None = None
        try:
            temporary = prepare_prod_preflight_copy(
                bundle_dir,
                prod_target=str(project["prod_target"]),
                validation_host=credentials.resolved_host(),
            )
            preflight_dir = Path(temporary.name) / "bundle"
            resolved_prod = runner.validate(
                str(project["prod_target"]), prod_variables, cwd=preflight_dir
            )
            policy_prod = _policy_or_raise(resolved_prod, project=project, environment="prod")
            flags["prod_bundle_preflight_valid"] = True
            details.append(f"Production preflight: {policy_prod.detail}")
        finally:
            if temporary is not None:
                temporary.cleanup()

        runner.deploy(str(project["dev_target"]), dev_variables)
        flags["deployment_succeeded"] = True
        outputs = _run_validation_resources(
            runner,
            target=str(project["dev_target"]),
            variables=dev_variables,
            resources=list(project.get("validation_resources") or []),
        )
        flags["workload_succeeded"] = True
        if outputs:
            details.append(f"Executed {len(outputs)} validation resource(s).")
        else:
            details.append("No validation job or pipeline was configured; deployment-only validation used.")

        summary = runner.summary(str(project["dev_target"]), dev_variables)
        _, project_tag_key, environment_tag_key = _tag_contract(project, "dev")
        tag_engine = TagEngine(
            credentials.workspace_client(),
            project_tag_key=project_tag_key,
            environment_tag_key=environment_tag_key,
        )
        tag_outcome = tag_engine.enforce(
            environment="dev",
            resolved=resolved_dev,
            summary=summary,
            catalog=str(project["dev_catalog"]),
            schema=str(project["dev_schema"]),
            additional_assets=list(project.get("additional_assets") or []),
            expected_tags=dict(project["required_tags"]["dev"]),
        )
        tag_results = list(tag_outcome.tag_results)
        if tag_outcome.failures:
            details.extend(tag_outcome.failures)

    except Exception as exc:
        details.append(str(exc))

    if client is None or not project or not repository or not revision:
        typer.echo(f"ERROR: {_detail(details) or 'Unable to resolve release context.'}", err=True)
        raise typer.Exit(2)

    payload = {
        "repository_uri": repository,
        "source_revision": revision,
        **flags,
        "detail": _detail(details),
        "run_url": run_url.strip(),
        "tag_results": tag_results,
    }
    _write_result(result_file, payload)
    try:
        result = client.report_dev(release_id, payload)
        _json(result)
    except Exception as exc:
        typer.echo(f"ERROR reporting dev result: {exc}", err=True)
        raise typer.Exit(2) from exc
    if not all(flags.values()) or any(item.get("status") == "FAIL" for item in tag_results) or not tag_results:
        raise typer.Exit(2)


@app.command("deploy-prod")
def deploy_prod(
    release_id: str = typer.Option(..., help="Approved release ID."),
    source_dir: Path = typer.Option(Path("."), exists=True, file_okay=False),
    repository_uri: str = typer.Option("", help="Repository URI; defaults to origin."),
    source_revision: str = typer.Option("", help="Full Git object ID; defaults to HEAD."),
    run_url: str = typer.Option("", help="CI run URL recorded with production evidence."),
    result_file: Path = typer.Option(
        Path("governance-prod-result.json"),
        help="JSON evidence file that can be replayed with complete-prod if App reporting fails.",
    ),
    app_url: str = typer.Option("", help="Direct Databricks App URL."),
) -> None:
    """Authorize and deploy the exact approved revision to production."""
    client: GovernanceAppClient | None = None
    repository = ""
    revision = ""
    project: dict[str, Any] = {}
    authorized = False
    flags = {
        "bundle_valid": False,
        "deployment_succeeded": False,
        "workload_succeeded": False,
    }
    details: list[str] = []
    tag_results: list[dict[str, str]] = []
    try:
        source = _source_dir(source_dir)
        repository, revision = _identity(source, repository_uri, source_revision)
        client = _client(_app_url(app_url))
        context = client.release_info(
            release_id, repository_uri=repository, source_revision=revision
        )
        project = dict(context["project"])
        repository = verify_checkout(
            source,
            expected_revision=str(context["release"]["source_revision"]),
            expected_repository=str(project["repository_uri"]),
            supplied_repository=repository,
        )
        bundle_dir = (source / str(project["bundle_path"])).resolve()
        if source not in bundle_dir.parents and bundle_dir != source:
            raise RuntimeError("Registered bundle_path resolves outside the Git checkout.")

        credentials = Credentials.from_environment("PROD")
        _assert_workspace_host(credentials, str(project["prod_workspace_host"]), "production")
        runner = BundleRunner(bundle_dir, credentials)
        variables = _workspace_variables(project, "prod")

        # Real production validation is intentionally completed before consuming approval.
        resolved = runner.validate(str(project["prod_target"]), variables)
        policy = _policy_or_raise(resolved, project=project, environment="prod")
        flags["bundle_valid"] = True
        details.append(policy.detail)

        client.authorize_prod(
            release_id,
            {"repository_uri": repository, "source_revision": revision},
        )
        authorized = True

        runner.deploy(str(project["prod_target"]), variables)
        flags["deployment_succeeded"] = True
        outputs = _run_validation_resources(
            runner,
            target=str(project["prod_target"]),
            variables=variables,
            resources=list(project.get("validation_resources") or []),
        )
        flags["workload_succeeded"] = True
        if outputs:
            details.append(f"Executed {len(outputs)} validation resource(s).")
        else:
            details.append("No validation job or pipeline was configured; deployment-only validation used.")

        summary = runner.summary(str(project["prod_target"]), variables)
        _, project_tag_key, environment_tag_key = _tag_contract(project, "prod")
        tag_engine = TagEngine(
            credentials.workspace_client(),
            project_tag_key=project_tag_key,
            environment_tag_key=environment_tag_key,
        )
        tag_outcome = tag_engine.enforce(
            environment="prod",
            resolved=resolved,
            summary=summary,
            catalog=str(project["prod_catalog"]),
            schema=str(project["prod_schema"]),
            additional_assets=list(project.get("additional_assets") or []),
            expected_tags=dict(project["required_tags"]["prod"]),
        )
        tag_results = list(tag_outcome.tag_results)
        if tag_outcome.failures:
            details.extend(tag_outcome.failures)
    except Exception as exc:
        details.append(str(exc))

    if not authorized:
        typer.echo(f"ERROR: {_detail(details) or 'Production authorization was not acquired.'}", err=True)
        raise typer.Exit(2)
    if client is None:
        typer.echo("ERROR: Governance client unavailable after production authorization.", err=True)
        raise typer.Exit(2)

    payload = {
        "repository_uri": repository,
        "source_revision": revision,
        **flags,
        "detail": _detail(details),
        "run_url": run_url.strip(),
        "tag_results": tag_results,
    }
    _write_result(result_file, payload)
    try:
        result = client.report_prod(release_id, payload)
        _json(result)
    except Exception as exc:
        typer.echo(f"ERROR reporting production result: {exc}", err=True)
        raise typer.Exit(2) from exc
    if not all(flags.values()) or any(item.get("status") == "FAIL" for item in tag_results) or not tag_results:
        raise typer.Exit(2)


@app.command("complete-prod")
def complete_prod(
    release_id: str = typer.Option(..., help="Release ID currently in DEPLOYING state."),
    result_file: Path = typer.Option(
        Path("governance-prod-result.json"), exists=True, dir_okay=False, readable=True
    ),
    app_url: str = typer.Option("", help="Direct Databricks App URL."),
) -> None:
    """Replay a saved production result after a temporary App/API reporting failure."""
    try:
        payload = json.loads(result_file.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise RuntimeError("Production result file must contain a JSON object.")
        _json(_client(_app_url(app_url)).report_prod(release_id, payload))
    except Exception as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(2) from exc


@app.command("status")
def status(
    release_id: str = typer.Option(..., help="Release ID."),
    repository_uri: str = typer.Option(..., help="Registered repository URI."),
    source_revision: str = typer.Option(..., help="Exact full Git revision."),
    app_url: str = typer.Option("", help="Direct Databricks App URL."),
) -> None:
    """Return CI-safe release and project context after exact identity verification."""
    try:
        _json(
            _client(_app_url(app_url)).release_info(
                release_id,
                repository_uri=repository_uri,
                source_revision=source_revision,
            )
        )
    except Exception as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(2) from exc


if __name__ == "__main__":
    app()
