from __future__ import annotations

import time
from typing import Any

import httpx

from governance_ci.auth import Credentials


class GovernanceAppClient:
    def __init__(self, app_url: str, credentials: Credentials, timeout: float = 90.0):
        self.app_url = app_url.strip().rstrip("/")
        if not self.app_url.startswith("https://") and not self.app_url.startswith("http://"):
            raise ValueError("app_url must be an HTTP(S) URL")
        self.credentials = credentials
        self.timeout = timeout
        self.workspace = credentials.workspace_client()

    def _headers(self, *, mutation: bool = False) -> dict[str, str]:
        headers = dict(self.workspace.config.authenticate())
        headers["Accept"] = "application/json"
        if mutation:
            headers["Content-Type"] = "application/json"
            headers["X-Governance-Request"] = "ci"
        return headers

    @staticmethod
    def _raise(response: httpx.Response) -> None:
        if response.is_success:
            return
        try:
            payload = response.json()
            detail = payload.get("detail") or payload.get("error") or payload
        except Exception:
            detail = response.text
        raise RuntimeError(f"Governance App request failed ({response.status_code}): {detail}")

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
        mutation: bool = False,
    ) -> dict[str, Any]:
        url = f"{self.app_url}{path}"
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                with httpx.Client(timeout=self.timeout, follow_redirects=False) as client:
                    response = client.request(
                        method,
                        url,
                        params=params or {},
                        json=payload,
                        headers=self._headers(mutation=mutation),
                    )
                if response.status_code not in {502, 503, 504}:
                    self._raise(response)
                    value = response.json()
                    if not isinstance(value, dict):
                        raise RuntimeError("Governance App returned an unexpected response.")
                    return value
                last_error = RuntimeError(
                    f"Governance App temporarily unavailable ({response.status_code})."
                )
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                last_error = exc
            if attempt < 2:
                time.sleep(2**attempt)
        raise RuntimeError(f"Governance App request failed after retries: {last_error}")

    def get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._request("GET", path, params=params)

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", path, payload=payload, mutation=True)

    def project_info(self, project_id: str) -> dict[str, Any]:
        return self.get(f"/api/v3/ci/projects/{project_id}")

    def release_info(
        self, release_id: str, *, repository_uri: str, source_revision: str
    ) -> dict[str, Any]:
        return self.get(
            f"/api/v3/ci/releases/{release_id}",
            params={"repository_uri": repository_uri, "source_revision": source_revision},
        )

    def report_dev(self, release_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post(f"/api/v3/ci/releases/{release_id}/dev-result", payload)

    def authorize_prod(self, release_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post(f"/api/v3/ci/releases/{release_id}/authorize-prod", payload)

    def report_prod(self, release_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post(f"/api/v3/ci/releases/{release_id}/prod-result", payload)
