from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.governance import (
    normalize_repository_uri,
    validate_identifier,
    validate_resource_key,
    validate_source_revision,
)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


def _optional_http_url(value: str, label: str) -> str:
    normalized = value.strip()
    if not normalized:
        return ""
    parsed = urlsplit(normalized)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        raise ValueError(f"{label} must be an HTTP(S) URL.")
    if parsed.username or parsed.password:
        raise ValueError(f"{label} cannot contain embedded credentials.")
    return normalized


class ValidationResource(StrictModel):
    type: Literal["job", "pipeline"]
    key: str

    @field_validator("key")
    @classmethod
    def valid_key(cls, value: str) -> str:
        return validate_resource_key(value, "validation resource key")


class AdditionalAsset(StrictModel):
    resource_type: Literal["job", "pipeline", "dashboard", "app", "schema", "table", "view", "volume"]
    identifier: str
    logical_name: str = ""
    environment: Literal["dev", "prod", "both"] = "both"

    @field_validator("identifier")
    @classmethod
    def non_empty_identifier(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Additional asset identifier cannot be empty.")
        return normalized

    @field_validator("logical_name")
    @classmethod
    def normalize_logical_name(cls, value: str) -> str:
        return value.strip()


class CicdConfig(StrictModel):
    repository_uri: str
    bundle_path: str = "."
    dev_target: str = "dev"
    prod_target: str = "prod"
    dev_catalog: str = "it_dev"
    dev_schema: str
    prod_catalog: str = "it_prod"
    prod_schema: str
    validation_resources: tuple[ValidationResource, ...] = ()
    additional_assets: tuple[AdditionalAsset, ...] = ()
    authorized_submitters: tuple[str, ...] = ()

    @field_validator("repository_uri")
    @classmethod
    def valid_repository(cls, value: str) -> str:
        return normalize_repository_uri(value).canonical_uri

    @field_validator("bundle_path")
    @classmethod
    def safe_bundle_path(cls, value: str) -> str:
        normalized = value.strip().strip("/") or "."
        if ".." in normalized.split("/"):
            raise ValueError("bundle_path cannot traverse outside the repository.")
        return normalized

    @field_validator("dev_target", "prod_target")
    @classmethod
    def valid_target(cls, value: str) -> str:
        return validate_resource_key(value, "Bundle target")

    @field_validator("dev_catalog", "dev_schema", "prod_catalog", "prod_schema")
    @classmethod
    def valid_identifier(cls, value: str, info: Any) -> str:
        return validate_identifier(value, info.field_name)

    @field_validator("authorized_submitters")
    @classmethod
    def normalize_submitters(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        return tuple(dict.fromkeys(str(item).strip().lower() for item in values if str(item).strip()))


class ProjectCreate(StrictModel):
    name: str
    team_name: str
    technical_owner_email: str
    business_owner_email: str
    description: str = ""
    data_classification: str = "Internal"
    cicd: CicdConfig

    @field_validator("name", "team_name", "technical_owner_email", "business_owner_email")
    @classmethod
    def required_text(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Required project fields cannot be empty.")
        return normalized

    @field_validator("technical_owner_email", "business_owner_email")
    @classmethod
    def valid_owner_email(cls, value: str) -> str:
        normalized = value.strip().lower()
        if "@" not in normalized:
            raise ValueError("Owner values must be email addresses.")
        return normalized


class ProjectUpdate(StrictModel):
    name: str | None = None
    team_name: str | None = None
    technical_owner_email: str | None = None
    business_owner_email: str | None = None
    description: str | None = None
    data_classification: str | None = None
    cicd: CicdConfig | None = None

    @field_validator("name", "team_name", "data_classification")
    @classmethod
    def optional_required_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("Updated project fields cannot be empty.")
        return normalized

    @field_validator("technical_owner_email", "business_owner_email")
    @classmethod
    def optional_owner_email(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip().lower()
        if not normalized or "@" not in normalized:
            raise ValueError("Owner values must be email addresses.")
        return normalized

    @field_validator("description")
    @classmethod
    def optional_description(cls, value: str | None) -> str | None:
        return None if value is None else value.strip()


class ProjectRecord(BaseModel):
    model_config = ConfigDict(extra="allow")
    project_id: str
    name: str
    team_name: str
    technical_owner_email: str
    business_owner_email: str
    description: str = ""
    data_classification: str = "Internal"
    lifecycle_status: str
    created_at: datetime | None = None
    created_by: str = ""
    updated_at: datetime | None = None
    updated_by: str = ""
    repository_uri: str
    repository_key: str
    repository_display_name: str
    source_provider: str
    bundle_path: str
    dev_target: str
    prod_target: str
    dev_catalog: str
    dev_schema: str
    prod_catalog: str
    prod_schema: str
    validation_resources: tuple[ValidationResource, ...] = ()
    additional_assets: tuple[AdditionalAsset, ...] = ()
    authorized_submitters: tuple[str, ...] = ()
    config_hash: str = ""


class ReleaseCreate(StrictModel):
    source_revision: str
    source_ref: str = ""
    pipeline_run_url: str = ""

    @field_validator("source_revision")
    @classmethod
    def revision(cls, value: str) -> str:
        return validate_source_revision(value)

    @field_validator("source_ref")
    @classmethod
    def normalize_source_ref(cls, value: str) -> str:
        return value.strip()

    @field_validator("pipeline_run_url")
    @classmethod
    def valid_pipeline_run_url(cls, value: str) -> str:
        return _optional_http_url(value, "pipeline_run_url")


class ReleaseRecord(BaseModel):
    model_config = ConfigDict(extra="allow")
    release_id: str
    project_id: str
    project_name: str = ""
    repository_uri: str
    repository_key: str
    source_revision: str
    source_ref: str = ""
    config_hash: str
    release_status: str
    dev_deployment_status: str
    dev_tag_check_passed: bool | None = None
    dev_tag_check_detail: str = ""
    dev_pipeline_run_url: str = ""
    dev_deployed_at: datetime | None = None
    requested_at: datetime | None = None
    requested_by: str = ""
    approved_at: datetime | None = None
    approved_by: str = ""
    decision_comment: str = ""
    prod_deployment_status: str
    prod_tag_check_passed: bool | None = None
    prod_tag_check_detail: str = ""
    prod_pipeline_run_url: str = ""
    prod_deployed_at: datetime | None = None
    deployment_message: str = ""
    updated_at: datetime | None = None
    updated_by: str = ""


class TagResult(StrictModel):
    environment: Literal["dev", "prod"]
    resource_type: str
    logical_name: str
    resource_identifier: str
    tag_key: str
    expected_value: str
    actual_value: str = ""
    verification_mode: str
    status: Literal["PASS", "FAIL", "MANAGED"]
    detail: str = ""

    @field_validator(
        "resource_type",
        "logical_name",
        "resource_identifier",
        "tag_key",
        "expected_value",
        "verification_mode",
    )
    @classmethod
    def required_result_text(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Tag evidence fields cannot be empty.")
        return normalized


class DevValidationReport(StrictModel):
    repository_uri: str
    source_revision: str
    dev_bundle_valid: bool
    prod_bundle_preflight_valid: bool
    deployment_succeeded: bool
    workload_succeeded: bool
    detail: str = ""
    run_url: str = ""
    tag_results: tuple[TagResult, ...] = ()

    @field_validator("repository_uri")
    @classmethod
    def repository(cls, value: str) -> str:
        return normalize_repository_uri(value).canonical_uri

    @field_validator("source_revision")
    @classmethod
    def revision(cls, value: str) -> str:
        return validate_source_revision(value)

    @field_validator("run_url")
    @classmethod
    def valid_run_url(cls, value: str) -> str:
        return _optional_http_url(value, "run_url")


class ProductionAuthorize(StrictModel):
    repository_uri: str
    source_revision: str

    @field_validator("repository_uri")
    @classmethod
    def repository(cls, value: str) -> str:
        return normalize_repository_uri(value).canonical_uri

    @field_validator("source_revision")
    @classmethod
    def revision(cls, value: str) -> str:
        return validate_source_revision(value)


class ProductionReport(StrictModel):
    repository_uri: str
    source_revision: str
    bundle_valid: bool
    deployment_succeeded: bool
    workload_succeeded: bool
    detail: str = ""
    run_url: str = ""
    tag_results: tuple[TagResult, ...] = ()

    @field_validator("repository_uri")
    @classmethod
    def repository(cls, value: str) -> str:
        return normalize_repository_uri(value).canonical_uri

    @field_validator("source_revision")
    @classmethod
    def revision(cls, value: str) -> str:
        return validate_source_revision(value)

    @field_validator("run_url")
    @classmethod
    def valid_run_url(cls, value: str) -> str:
        return _optional_http_url(value, "run_url")


class DecisionRequest(StrictModel):
    approve: bool
    comment: str = Field(default="", max_length=4000)


class ProjectStatusRequest(StrictModel):
    status: Literal["ACTIVE", "SUSPENDED", "RETIRED"]
    comment: str = Field(default="", max_length=4000)


class DeploymentFailureRequest(StrictModel):
    comment: str = Field(min_length=1, max_length=4000)

    @field_validator("comment")
    @classmethod
    def required_comment(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("A recovery reason is required.")
        return normalized
