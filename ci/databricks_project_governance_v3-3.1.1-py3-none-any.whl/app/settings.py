from __future__ import annotations

import os
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")
_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_REQUIRED_TABLES = ("projects", "project_cicd", "releases", "resource_tags", "audit")


class SettingsError(ValueError):
    """Raised when the application configuration is missing or invalid."""


def _expand_environment(text: str) -> str:
    def replace(match: re.Match[str]) -> str:
        name, default = match.group(1), match.group(2)
        value = os.getenv(name)
        return value if value is not None else (default or "")

    return _ENV_PATTERN.sub(replace, text)


def _mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise SettingsError(f"{label} must be a YAML mapping.")
    return value


def _principal_set(value: Any, label: str) -> frozenset[str]:
    if value is None:
        return frozenset()
    if not isinstance(value, list):
        raise SettingsError(f"{label} must be a YAML list.")
    return frozenset(str(item).strip().lower() for item in value if str(item).strip())


@dataclass(frozen=True)
class Settings:
    path: Path
    raw: dict[str, Any]

    @property
    def app(self) -> dict[str, Any]:
        return _mapping(self.raw.get("app"), "app")

    @property
    def database(self) -> dict[str, Any]:
        return _mapping(self.raw.get("database"), "database")

    @property
    def security(self) -> dict[str, Any]:
        return _mapping(self.raw.get("security"), "security")

    @property
    def governance(self) -> dict[str, Any]:
        return _mapping(self.raw.get("governance"), "governance")

    @property
    def workspaces(self) -> dict[str, Any]:
        return _mapping(self.raw.get("workspaces"), "workspaces")

    @property
    def title(self) -> str:
        return str(self.app.get("title", "Project Registry & Governance v3"))

    @property
    def warehouse_id(self) -> str:
        env_name = str(self.database.get("warehouse_id_env", "DATABRICKS_WAREHOUSE_ID"))
        value = os.getenv(env_name, "").strip()
        if not value:
            raise SettingsError(
                f"Environment variable {env_name} is empty. Bind a SQL warehouse to the Databricks App."
            )
        return value

    @property
    def admin_principals(self) -> frozenset[str]:
        return _principal_set(self.security.get("admin_principals"), "security.admin_principals")

    @property
    def approver_principals(self) -> frozenset[str]:
        return _principal_set(
            self.security.get("approver_principals"), "security.approver_principals"
        )

    @property
    def production_deployer_principals(self) -> frozenset[str]:
        return _principal_set(
            self.security.get("production_deployer_principals"),
            "security.production_deployer_principals",
        )

    @property
    def allow_submitter_to_approve(self) -> bool:
        return bool(self.security.get("allow_submitter_to_approve", False))

    @property
    def auto_activate_admin_created_projects(self) -> bool:
        return bool(self.security.get("auto_activate_admin_created_projects", True))

    @property
    def allow_admin_as_production_deployer(self) -> bool:
        return bool(self.security.get("allow_admin_as_production_deployer", False))

    @property
    def allow_local_development(self) -> bool:
        return bool(self.security.get("allow_local_development", False))

    @property
    def local_user_env(self) -> str:
        return str(self.security.get("local_user_env", "LOCAL_DEV_USER_EMAIL"))

    @property
    def dev_host(self) -> str:
        return str(self.workspaces.get("dev_host", "")).strip().rstrip("/")

    @property
    def prod_host(self) -> str:
        return str(self.workspaces.get("prod_host", "")).strip().rstrip("/")

    @property
    def project_tag_key(self) -> str:
        return str(self.governance.get("project_tag_key", "project_tag"))

    @property
    def environment_tag_key(self) -> str:
        return str(self.governance.get("environment_tag_key", "environment"))

    def table(self, key: str) -> str:
        tables = _mapping(self.database.get("tables"), "database.tables")
        catalog = str(self.database.get("catalog", "")).strip()
        schema = str(self.database.get("schema", "")).strip()
        table = str(tables.get(key, "")).strip()
        for label, identifier in (("catalog", catalog), ("schema", schema), (f"table {key}", table)):
            if not _IDENTIFIER.fullmatch(identifier):
                raise SettingsError(f"Invalid {label} identifier: {identifier!r}")
        return f"`{catalog}`.`{schema}`.`{table}`"

    def raw_table_name(self, key: str) -> str:
        tables = _mapping(self.database.get("tables"), "database.tables")
        value = str(tables.get(key, "")).strip()
        if not _IDENTIFIER.fullmatch(value):
            raise SettingsError(f"Invalid table identifier: {value!r}")
        return value


def load_settings(path: str | Path | None = None) -> Settings:
    resolved = Path(path or os.getenv("APP_CONFIG_PATH", "config/app_config.yaml")).resolve()
    if not resolved.exists():
        raise SettingsError(f"Configuration file not found: {resolved}")
    raw = _mapping(yaml.safe_load(_expand_environment(resolved.read_text(encoding="utf-8"))), "root")
    if int(raw.get("config_version", 0)) != 3:
        raise SettingsError("config_version must be 3.")
    settings = Settings(resolved, raw)
    for table in _REQUIRED_TABLES:
        settings.table(table)
    if not settings.dev_host or not settings.prod_host:
        raise SettingsError("workspaces.dev_host and workspaces.prod_host are required.")
    return settings


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return load_settings()
