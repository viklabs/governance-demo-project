from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app import __version__
from app.api import router as api_router
from app.db import RegistryDatabase
from app.governance import (
    AuthorizationError,
    ConflictError,
    GovernanceError,
    NotFoundError,
    ValidationError,
)
from app.service import RegistryService
from app.settings import Settings, get_settings
from app.ui import router as ui_router


def create_app(
    *,
    settings: Settings | None = None,
    repository: Any | None = None,
    bootstrap: bool = True,
) -> FastAPI:
    resolved_settings = settings or get_settings()

    @asynccontextmanager
    async def lifespan(application: FastAPI):
        database = repository or RegistryDatabase(resolved_settings)
        service = RegistryService(resolved_settings, database)
        application.state.settings = resolved_settings
        application.state.service = service
        if bootstrap:
            service.bootstrap()
        yield

    application = FastAPI(
        title=resolved_settings.title,
        version=__version__,
        description=(
            "Provider-neutral project registration, mandatory Databricks tag evidence, "
            "and exact-revision production approval."
        ),
        lifespan=lifespan,
    )
    application.mount(
        "/static",
        StaticFiles(directory=str(Path(__file__).resolve().parent / "static")),
        name="static",
    )
    application.include_router(api_router)
    application.include_router(ui_router)

    @application.exception_handler(GovernanceError)
    async def governance_error(_: Request, exc: GovernanceError) -> JSONResponse:
        status_code = 422
        if isinstance(exc, AuthorizationError):
            status_code = 403
        elif isinstance(exc, NotFoundError):
            status_code = 404
        elif isinstance(exc, ConflictError):
            status_code = 409
        elif isinstance(exc, ValidationError):
            status_code = 422
        return JSONResponse(
            status_code=status_code,
            content={"error": exc.__class__.__name__, "detail": str(exc)},
        )

    @application.exception_handler(RequestValidationError)
    async def request_validation_error(_: Request, exc: RequestValidationError) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content={"error": "RequestValidationError", "detail": exc.errors()},
        )

    @application.get("/health", include_in_schema=False)
    def root_health(request: Request) -> dict[str, object]:
        service: RegistryService = request.app.state.service
        database = service.health()
        return {
            "status": "ok" if database.get("ok") else "degraded",
            "version": __version__,
            "database": database,
        }

    return application


app = create_app()
