from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from app.auth import Actor
from app.dependencies import get_actor, get_service, mutation_guard
from app.models import (
    DecisionRequest,
    DeploymentFailureRequest,
    DevValidationReport,
    ProductionAuthorize,
    ProductionReport,
    ProjectCreate,
    ProjectRecord,
    ProjectStatusRequest,
    ProjectUpdate,
    ReleaseCreate,
    ReleaseRecord,
)
from app.service import RegistryService

router = APIRouter(prefix="/api/v3", tags=["governance-v3"])


@router.get("/health")
def health(service: RegistryService = Depends(get_service)) -> dict[str, Any]:
    value = service.health()
    return {"ok": bool(value.get("ok")), "version": "3.1.1", "database": value}


@router.get("/me")
def me(
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> dict[str, Any]:
    return {
        "actor": actor.normalized,
        "display_name": actor.display_name,
        "is_admin": service.authorization.is_admin(actor),
        "is_approver": service.authorization.is_approver(actor),
        "is_production_deployer": service.authorization.is_production_deployer(actor),
    }


@router.get("/dashboard")
def dashboard(
    _actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> dict[str, Any]:
    return service.dashboard()


@router.post(
    "/projects",
    response_model=ProjectRecord,
    status_code=201,
    dependencies=[Depends(mutation_guard)],
)
def create_project(
    payload: ProjectCreate,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ProjectRecord:
    return service.create_project(payload, actor)


@router.get("/projects", response_model=list[ProjectRecord])
def list_projects(
    status: str | None = Query(default=None),
    _actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> list[ProjectRecord]:
    return service.list_projects(status)


@router.get("/projects/by-repository", response_model=ProjectRecord)
def project_by_repository(
    repository_uri: str,
    _actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ProjectRecord:
    return service.get_project_by_repository(repository_uri)


@router.get("/projects/{project_id}", response_model=ProjectRecord)
def get_project(
    project_id: str,
    _actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ProjectRecord:
    return service.get_project(project_id)


@router.put(
    "/projects/{project_id}",
    response_model=ProjectRecord,
    dependencies=[Depends(mutation_guard)],
)
def update_project(
    project_id: str,
    payload: ProjectUpdate,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ProjectRecord:
    return service.update_project(project_id, payload, actor)


@router.post(
    "/projects/{project_id}/decision",
    response_model=ProjectRecord,
    dependencies=[Depends(mutation_guard)],
)
def decide_project(
    project_id: str,
    payload: DecisionRequest,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ProjectRecord:
    return service.decide_project(
        project_id, approve=payload.approve, comment=payload.comment, actor=actor
    )


@router.post(
    "/projects/{project_id}/status",
    response_model=ProjectRecord,
    dependencies=[Depends(mutation_guard)],
)
def project_status(
    project_id: str,
    payload: ProjectStatusRequest,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ProjectRecord:
    return service.set_project_status(
        project_id, status=payload.status, comment=payload.comment, actor=actor
    )


@router.get("/projects/{project_id}/bootstrap")
def bootstrap_project(
    project_id: str,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> dict[str, Any]:
    project = service.database.get_project(project_id)
    service.authorization.require_project_manager(project, actor)
    return {
        "project": service._ci_project_payload(project),
        "bundle_variables": ["project_id", "environment_name", "catalog_name", "schema_name"],
        "resource_tags": {
            "project_tag": "${var.project_id}",
            "environment": "${var.environment_name}",
        },
        "branch_policy": "Source ref is optional metadata. The same branch may be used for dev and prod.",
        "commands": {
            "validate": (
                f"governance-ci validate-release --app-url <APP_URL> --release-id <RELEASE_ID> "
                f"--source-revision <FULL_SHA>"
            ),
            "deploy_prod": (
                f"governance-ci deploy-prod --app-url <APP_URL> --release-id <RELEASE_ID> "
                f"--source-revision <FULL_SHA>"
            ),
        },
    }


@router.post(
    "/projects/{project_id}/releases",
    response_model=ReleaseRecord,
    status_code=201,
    dependencies=[Depends(mutation_guard)],
)
def create_release(
    project_id: str,
    payload: ReleaseCreate,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ReleaseRecord:
    return service.create_release(project_id, payload, actor)


@router.get("/releases", response_model=list[ReleaseRecord])
def list_releases(
    status: str | None = Query(default=None),
    project_id: str | None = Query(default=None),
    _actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> list[ReleaseRecord]:
    return service.list_releases(status=status, project_id=project_id)


@router.get("/releases/{release_id}")
def release_detail(
    release_id: str,
    _actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> dict[str, Any]:
    value = service.release_detail(release_id)
    return {
        "release": value["release"].model_dump(mode="json"),
        "project": value["project"].model_dump(mode="json"),
        "tags": value["tags"],
    }


@router.post(
    "/releases/{release_id}/decision",
    response_model=ReleaseRecord,
    dependencies=[Depends(mutation_guard)],
)
def decide_release(
    release_id: str,
    payload: DecisionRequest,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ReleaseRecord:
    return service.decide_release(
        release_id, approve=payload.approve, comment=payload.comment, actor=actor
    )


@router.post(
    "/releases/{release_id}/mark-deploy-failed",
    response_model=ReleaseRecord,
    dependencies=[Depends(mutation_guard)],
)
def mark_deploy_failed(
    release_id: str,
    payload: DeploymentFailureRequest,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ReleaseRecord:
    return service.mark_production_failed(
        release_id, comment=payload.comment, actor=actor
    )


@router.get("/resource-tags")
def resource_tags(
    release_id: str | None = Query(default=None),
    _actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> list[dict[str, Any]]:
    return service.list_resource_tags(release_id)


@router.get("/audit")
def audit(
    limit: int = Query(default=500, ge=1, le=5000),
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> list[dict[str, Any]]:
    return service.list_audit(actor, limit)


# CI endpoints -----------------------------------------------------------------
@router.get("/ci/projects/{project_id}")
def ci_project_info(
    project_id: str,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> dict[str, Any]:
    return service.ci_project_info(project_id, actor)


@router.get("/ci/releases/{release_id}")
def ci_release_info(
    release_id: str,
    repository_uri: str,
    source_revision: str,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> dict[str, Any]:
    return service.ci_release_info(
        release_id,
        repository_uri=repository_uri,
        source_revision=source_revision,
        actor=actor,
    )


@router.post(
    "/ci/releases/{release_id}/dev-result",
    response_model=ReleaseRecord,
    dependencies=[Depends(mutation_guard)],
)
def ci_dev_result(
    release_id: str,
    payload: DevValidationReport,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ReleaseRecord:
    return service.record_dev_validation(release_id, payload, actor)


@router.post(
    "/ci/releases/{release_id}/authorize-prod",
    dependencies=[Depends(mutation_guard)],
)
def ci_authorize_prod(
    release_id: str,
    payload: ProductionAuthorize,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> dict[str, Any]:
    return service.authorize_production(release_id, payload, actor)


@router.post(
    "/ci/releases/{release_id}/prod-result",
    response_model=ReleaseRecord,
    dependencies=[Depends(mutation_guard)],
)
def ci_prod_result(
    release_id: str,
    payload: ProductionReport,
    actor: Actor = Depends(get_actor),
    service: RegistryService = Depends(get_service),
) -> ReleaseRecord:
    return service.record_production_result(release_id, payload, actor)
