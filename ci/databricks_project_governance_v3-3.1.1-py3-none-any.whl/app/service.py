from __future__ import annotations

from typing import Any

from app.auth import Actor, Authorization
from app.db import RegistryDatabase
from app.governance import (
    PROJECT_ACTIVE,
    RELEASE_READY,
    ConflictError,
    expected_tags,
)
from app.models import (
    DevValidationReport,
    ProductionAuthorize,
    ProductionReport,
    ProjectCreate,
    ProjectRecord,
    ProjectUpdate,
    ReleaseCreate,
    ReleaseRecord,
)
from app.settings import Settings


class RegistryService:
    def __init__(self, settings: Settings, database: RegistryDatabase):
        self.settings = settings
        self.database = database
        self.authorization = Authorization(settings)

    def bootstrap(self) -> None:
        self.database.ensure_tables()
        self.database.validate_schema()

    def health(self) -> dict[str, Any]:
        return self.database.health()

    def dashboard(self) -> dict[str, Any]:
        return self.database.dashboard()

    def create_project(self, payload: ProjectCreate, actor: Actor) -> ProjectRecord:
        active = self.authorization.is_admin(actor) and self.settings.auto_activate_admin_created_projects
        return ProjectRecord.model_validate(
            self.database.create_project(payload, actor.normalized, active=active)
        )

    def list_projects(self, status: str | None = None) -> list[ProjectRecord]:
        return [ProjectRecord.model_validate(item) for item in self.database.list_projects(status)]

    def get_project(self, project_id: str) -> ProjectRecord:
        return ProjectRecord.model_validate(self.database.get_project(project_id))

    def get_project_by_repository(self, repository_uri: str) -> ProjectRecord:
        return ProjectRecord.model_validate(self.database.get_project_by_repository(repository_uri))

    def update_project(self, project_id: str, payload: ProjectUpdate, actor: Actor) -> ProjectRecord:
        # Delivery configuration controls which repository, targets, schemas, and CI identities
        # can participate in governed promotion. Keep changes administrator-controlled after
        # registration so a project owner cannot add an untrusted evidence submitter.
        self.authorization.require_admin(actor)
        return ProjectRecord.model_validate(
            self.database.update_project(project_id, payload, actor.normalized)
        )

    def decide_project(
        self, project_id: str, *, approve: bool, comment: str, actor: Actor
    ) -> ProjectRecord:
        self.authorization.require_admin(actor)
        return ProjectRecord.model_validate(
            self.database.decide_project(
                project_id, approve=approve, actor=actor.normalized, comment=comment
            )
        )

    def set_project_status(
        self, project_id: str, *, status: str, comment: str, actor: Actor
    ) -> ProjectRecord:
        self.authorization.require_admin(actor)
        return ProjectRecord.model_validate(
            self.database.set_project_status(project_id, status, actor.normalized, comment)
        )

    def create_release(
        self, project_id: str, payload: ReleaseCreate, actor: Actor
    ) -> ReleaseRecord:
        project = self.database.get_project(project_id)
        self.authorization.require_project_manager(project, actor)
        return ReleaseRecord.model_validate(
            self.database.create_release(
                project_id,
                payload.source_revision,
                payload.source_ref,
                payload.pipeline_run_url,
                actor.normalized,
            )
        )

    def list_releases(
        self, *, status: str | None = None, project_id: str | None = None
    ) -> list[ReleaseRecord]:
        return [
            ReleaseRecord.model_validate(item)
            for item in self.database.list_releases(status=status, project_id=project_id)
        ]

    def get_release(self, release_id: str) -> ReleaseRecord:
        return ReleaseRecord.model_validate(self.database.get_release(release_id))

    def release_detail(self, release_id: str) -> dict[str, Any]:
        release = self.database.get_release(release_id)
        return {
            "release": ReleaseRecord.model_validate(release),
            "project": ProjectRecord.model_validate(self.database.get_project(release["project_id"])),
            "tags": self.database.list_resource_tags(release_id),
        }

    def ci_project_info(self, project_id: str, actor: Actor) -> dict[str, Any]:
        project = self.database.get_project(project_id)
        if not self.authorization.is_production_deployer(actor):
            self.authorization.require_ci_submitter(project, actor)
        return self._ci_project_payload(project)

    def ci_release_info(
        self,
        release_id: str,
        *,
        repository_uri: str,
        source_revision: str,
        actor: Actor,
    ) -> dict[str, Any]:
        release = self.database.ci_release_info(release_id, repository_uri, source_revision)
        project = self.database.get_project(release["project_id"])
        if not self.authorization.is_production_deployer(actor):
            self.authorization.require_ci_submitter(project, actor)
        return {
            "release": ReleaseRecord.model_validate(release).model_dump(mode="json"),
            "project": self._ci_project_payload(project),
        }

    def record_dev_validation(
        self, release_id: str, report: DevValidationReport, actor: Actor
    ) -> ReleaseRecord:
        release = self.database.get_release(release_id)
        project = self.database.get_project(release["project_id"])
        self.authorization.require_ci_submitter(project, actor)
        return ReleaseRecord.model_validate(
            self.database.record_dev_validation(release_id, report, actor.normalized)
        )

    def decide_release(
        self, release_id: str, *, approve: bool, comment: str, actor: Actor
    ) -> ReleaseRecord:
        self.authorization.require_approver(actor)
        release = self.database.get_release(release_id)
        if release["release_status"] != RELEASE_READY:
            raise ConflictError("Only READY_FOR_APPROVAL releases can be approved or rejected.")
        if (
            not self.settings.allow_submitter_to_approve
            and actor.normalized == str(release["requested_by"]).strip().lower()
        ):
            raise ConflictError("Release requester cannot approve their own release.")
        return ReleaseRecord.model_validate(
            self.database.decide_release(
                release_id, approve=approve, actor=actor.normalized, comment=comment
            )
        )

    def authorize_production(
        self, release_id: str, payload: ProductionAuthorize, actor: Actor
    ) -> dict[str, Any]:
        self.authorization.require_production_deployer(actor)
        release = self.database.authorize_production(
            release_id,
            repository_uri=payload.repository_uri,
            source_revision=payload.source_revision,
            actor=actor.normalized,
        )
        project = self.database.get_project(release["project_id"])
        return {
            "authorized": True,
            "release": ReleaseRecord.model_validate(release).model_dump(mode="json"),
            "project": self._ci_project_payload(project),
        }

    def record_production_result(
        self, release_id: str, report: ProductionReport, actor: Actor
    ) -> ReleaseRecord:
        self.authorization.require_production_deployer(actor)
        return ReleaseRecord.model_validate(
            self.database.record_production_result(release_id, report, actor.normalized)
        )

    def mark_production_failed(
        self, release_id: str, *, comment: str, actor: Actor
    ) -> ReleaseRecord:
        self.authorization.require_admin(actor)
        return ReleaseRecord.model_validate(
            self.database.mark_production_failed(release_id, actor.normalized, comment)
        )

    def list_resource_tags(self, release_id: str | None = None) -> list[dict[str, Any]]:
        return self.database.list_resource_tags(release_id)

    def list_audit(self, actor: Actor, limit: int = 500) -> list[dict[str, Any]]:
        self.authorization.require_admin(actor)
        return self.database.list_audit(limit)

    def _ci_project_payload(self, project: dict[str, Any]) -> dict[str, Any]:
        if project["lifecycle_status"] != PROJECT_ACTIVE:
            raise ConflictError("Project is not active.")
        return {
            "project_id": project["project_id"],
            "name": project["name"],
            "repository_uri": project["repository_uri"],
            "repository_key": project["repository_key"],
            "source_provider": project["source_provider"],
            "bundle_path": project["bundle_path"],
            "dev_target": project["dev_target"],
            "prod_target": project["prod_target"],
            "dev_catalog": project["dev_catalog"],
            "dev_schema": project["dev_schema"],
            "prod_catalog": project["prod_catalog"],
            "prod_schema": project["prod_schema"],
            "dev_workspace_host": self.settings.dev_host,
            "prod_workspace_host": self.settings.prod_host,
            "validation_resources": list(project["validation_resources"]),
            "additional_assets": list(project["additional_assets"]),
            "config_hash": project["config_hash"],
            "required_tags": {
                "dev": expected_tags(project["project_id"], "dev", self.settings),
                "prod": expected_tags(project["project_id"], "prod", self.settings),
            },
        }
