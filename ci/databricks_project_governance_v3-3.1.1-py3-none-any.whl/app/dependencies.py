from __future__ import annotations

from fastapi import Request

from app.auth import Actor, actor_from_request, require_mutation_request
from app.service import RegistryService


def get_service(request: Request) -> RegistryService:
    return request.app.state.service


def get_actor(request: Request) -> Actor:
    return actor_from_request(request, request.app.state.settings)


def mutation_guard(request: Request) -> None:
    require_mutation_request(request)
