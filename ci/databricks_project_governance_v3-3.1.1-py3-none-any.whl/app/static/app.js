(() => {
  const flash = document.getElementById('flash');
  const show = (message, kind = 'error') => {
    if (!flash) return;
    flash.textContent = message;
    flash.className = `flash ${kind}`;
    flash.hidden = false;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const api = async (url, options = {}) => {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'X-Governance-Request': 'ui',
        ...(options.headers || {})
      }
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      const detail = typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail || body);
      throw new Error(detail || `Request failed (${response.status})`);
    }
    return body;
  };
  const split = (value) => String(value || '').split(/[\n,]+/).map(v => v.trim()).filter(Boolean);

  const projectForm = document.getElementById('project-form');
  if (projectForm) projectForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(projectForm));
    let additionalAssets = [];
    try { additionalAssets = JSON.parse(data.additional_assets_json || '[]'); }
    catch (_) { show('Additional assets must be valid JSON.'); return; }
    const validationResources = [
      ...split(data.validation_jobs).map(key => ({ type: 'job', key })),
      ...split(data.validation_pipelines).map(key => ({ type: 'pipeline', key }))
    ];
    const payload = {
      name: data.name,
      team_name: data.team_name,
      technical_owner_email: data.technical_owner_email,
      business_owner_email: data.business_owner_email,
      description: data.description,
      data_classification: data.data_classification,
      cicd: {
        repository_uri: data.repository_uri,
        bundle_path: data.bundle_path,
        dev_target: data.dev_target,
        prod_target: data.prod_target,
        dev_catalog: data.dev_catalog,
        dev_schema: data.dev_schema,
        prod_catalog: data.prod_catalog,
        prod_schema: data.prod_schema,
        validation_resources: validationResources,
        additional_assets: additionalAssets,
        authorized_submitters: split(data.authorized_submitters)
      }
    };
    try {
      const value = await api(projectForm.dataset.api, { method: 'POST', body: JSON.stringify(payload) });
      location.href = projectForm.dataset.success.replace('{project_id}', value.project_id);
    } catch (error) { show(error.message); }
  });

  const editForm = document.getElementById('project-edit-form');
  if (editForm) editForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(editForm));
    let additionalAssets = [];
    try { additionalAssets = JSON.parse(data.additional_assets_json || '[]'); }
    catch (_) { show('Additional assets must be valid JSON.'); return; }
    const payload = {
      name: data.name, team_name: data.team_name,
      technical_owner_email: data.technical_owner_email, business_owner_email: data.business_owner_email,
      description: data.description, data_classification: data.data_classification,
      cicd: {
        repository_uri: data.repository_uri, bundle_path: data.bundle_path,
        dev_target: data.dev_target, prod_target: data.prod_target,
        dev_catalog: data.dev_catalog, dev_schema: data.dev_schema,
        prod_catalog: data.prod_catalog, prod_schema: data.prod_schema,
        validation_resources: [
          ...split(data.validation_jobs).map(key => ({ type: 'job', key })),
          ...split(data.validation_pipelines).map(key => ({ type: 'pipeline', key }))
        ],
        additional_assets: additionalAssets, authorized_submitters: split(data.authorized_submitters)
      }
    };
    try { await api(editForm.dataset.api, { method: 'PUT', body: JSON.stringify(payload) }); location.href = editForm.dataset.success; }
    catch (error) { show(error.message); }
  });

  const releaseForm = document.getElementById('release-form');
  if (releaseForm) releaseForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(releaseForm));
    const payload = { source_revision: data.source_revision, source_ref: data.source_ref, pipeline_run_url: data.pipeline_run_url };
    try {
      const value = await api(`/api/v3/projects/${encodeURIComponent(data.project_id)}/releases`, { method: 'POST', body: JSON.stringify(payload) });
      location.href = releaseForm.dataset.success.replace('{release_id}', value.release_id);
    } catch (error) { show(error.message); }
  });

  document.querySelectorAll('.api-decision').forEach(button => button.addEventListener('click', async () => {
    const approve = button.dataset.approve === 'true';
    const comment = window.prompt(approve ? 'Approval comment (optional)' : 'Reason for rejection', '') ?? null;
    if (comment === null) return;
    button.disabled = true;
    try {
      await api(button.dataset.url, { method: 'POST', body: JSON.stringify({ approve, comment }) });
      location.href = button.dataset.redirect;
    } catch (error) { show(error.message); button.disabled = false; }
  }));

  document.querySelectorAll('.api-status').forEach(button => button.addEventListener('click', async () => {
    const comment = window.prompt(`Reason for ${button.dataset.status.toLowerCase()}`, '') ?? null;
    if (comment === null) return;
    try {
      await api(button.dataset.url, { method: 'POST', body: JSON.stringify({ status: button.dataset.status, comment }) });
      location.reload();
    } catch (error) { show(error.message); }
  }));

  document.querySelectorAll('.api-mark-failed').forEach(button => button.addEventListener('click', async () => {
    const comment = window.prompt('Why is this DEPLOYING release being closed as failed?', '') ?? null;
    if (comment === null) return;
    if (!comment.trim()) { show('A recovery reason is required.'); return; }
    button.disabled = true;
    try {
      await api(button.dataset.url, { method: 'POST', body: JSON.stringify({ comment }) });
      location.reload();
    } catch (error) { show(error.message); button.disabled = false; }
  }));

  document.querySelectorAll('.copy').forEach(button => button.addEventListener('click', async () => {
    const target = document.getElementById(button.dataset.copyTarget);
    if (!target) return;
    await navigator.clipboard.writeText(target.innerText);
    button.textContent = 'Copied';
    setTimeout(() => { button.textContent = 'Copy'; }, 1200);
  }));
})();
