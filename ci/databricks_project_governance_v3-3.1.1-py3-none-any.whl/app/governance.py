from __future__ import annotations

import hashlib
import json
import re
import secrets
import string
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping
from urllib.parse import quote, unquote, urlsplit, urlunsplit

from app.settings import Settings

PROJECT_PENDING = "PENDING_APPROVAL"
PROJECT_ACTIVE = "ACTIVE"
PROJECT_REJECTED = "REJECTED"
PROJECT_SUSPENDED = "SUSPENDED"
PROJECT_RETIRED = "RETIRED"

RELEASE_VALIDATING = "VALIDATING"
RELEASE_CHECKS_FAILED = "CHECKS_FAILED"
RELEASE_READY = "READY_FOR_APPROVAL"
RELEASE_APPROVED = "APPROVED"
RELEASE_REJECTED = "REJECTED"
RELEASE_DEPLOYING = "DEPLOYING"
RELEASE_DEPLOYED = "DEPLOYED"
RELEASE_FAILED = "DEPLOY_FAILED"

DEV_PENDING = "PENDING"
DEV_DEPLOYED = "DEPLOYED"
DEV_FAILED = "FAILED"
PROD_PENDING = "PENDING"
PROD_DEPLOYING = "DEPLOYING"
PROD_DEPLOYED = "DEPLOYED"
PROD_FAILED = "FAILED"

PROJECT_STATUSES = {
    PROJECT_PENDING,
    PROJECT_ACTIVE,
    PROJECT_REJECTED,
    PROJECT_SUSPENDED,
    PROJECT_RETIRED,
}
RELEASE_STATUSES = {
    RELEASE_VALIDATING,
    RELEASE_CHECKS_FAILED,
    RELEASE_READY,
    RELEASE_APPROVED,
    RELEASE_REJECTED,
    RELEASE_DEPLOYING,
    RELEASE_DEPLOYED,
    RELEASE_FAILED,
}

_SCP_STYLE = re.compile(r"^(?P<user>[A-Za-z0-9_.-]+)@(?P<host>[^:/\s]+):(?P<path>[^\s]+)$")
_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_RESOURCE_KEY = re.compile(r"^[A-Za-z0-9_.-]+$")


class GovernanceError(ValueError):
    """Base class for user-facing governance errors."""


class AuthorizationError(GovernanceError):
    """Raised when an actor is not allowed to perform an operation."""


class ConflictError(GovernanceError):
    """Raised when an operation conflicts with current registry state."""


class NotFoundError(GovernanceError):
    """Raised when a project or release is absent."""


class ValidationError(GovernanceError):
    """Raised for invalid project, release, or CI evidence."""


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def generate_id(prefix: str, length: int) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return f"{prefix}-" + "".join(secrets.choice(alphabet) for _ in range(length))


def validate_source_revision(value: str) -> str:
    revision = value.strip().lower()
    if not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", revision):
        raise ValidationError("Source revision must be a full 40- or 64-character hexadecimal Git object ID.")
    return revision


def validate_identifier(value: str, label: str) -> str:
    normalized = value.strip()
    if not _IDENTIFIER.fullmatch(normalized):
        raise ValidationError(f"{label} must be a valid Databricks identifier.")
    return normalized


def validate_resource_key(value: str, label: str = "resource key") -> str:
    normalized = value.strip()
    if not normalized or not _RESOURCE_KEY.fullmatch(normalized):
        raise ValidationError(f"{label} contains unsupported characters.")
    return normalized


@dataclass(frozen=True)
class RepositoryIdentity:
    original_uri: str
    canonical_uri: str
    repository_key: str
    host: str
    display_name: str
    provider: str


def infer_provider(host: str) -> str:
    value = host.lower()
    if value == "github.com":
        return "GitHub"
    if value == "bitbucket.org":
        return "Bitbucket Cloud"
    if value == "gitlab.com":
        return "GitLab"
    if value in {"dev.azure.com", "ssh.dev.azure.com"} or value.endswith(".visualstudio.com"):
        return "Azure DevOps"
    if "bitbucket" in value:
        return "Bitbucket Server/Data Center"
    if "github" in value:
        return "GitHub Enterprise"
    if "gitlab" in value:
        return "GitLab Self-Managed"
    if "git-codecommit" in value and value.endswith("amazonaws.com"):
        return "AWS CodeCommit"
    return "Generic Git"


def normalize_repository_uri(value: str) -> RepositoryIdentity:
    original = value.strip()
    if not original:
        raise ValidationError("Repository URI is required.")
    match = _SCP_STYLE.fullmatch(original)
    parse_value = (
        f"ssh://{match.group('user')}@{match.group('host')}/{match.group('path').lstrip('/')}"
        if match
        else original
    )
    parsed = urlsplit(parse_value)
    scheme = parsed.scheme.lower()
    if scheme not in {"https", "http", "ssh", "git"}:
        raise ValidationError("Repository URI must use HTTPS, HTTP, SSH, Git, or scp-style Git syntax.")
    if not parsed.hostname:
        raise ValidationError("Repository URI must include a host name.")
    if parsed.query or parsed.fragment:
        raise ValidationError("Repository URI cannot contain query parameters or fragments.")
    if parsed.password:
        raise ValidationError("Repository URI cannot contain embedded credentials.")
    if scheme in {"http", "https"} and parsed.username:
        raise ValidationError(
            "Repository URI cannot contain an HTTP(S) username or token. Register the clean repository URL."
        )
    host = parsed.hostname.lower().rstrip(".")
    port = f":{parsed.port}" if parsed.port else ""
    username = parsed.username or ("git" if scheme == "ssh" else "")
    user_info = f"{quote(username, safe='')}@" if username else ""
    path = unquote(parsed.path).strip().strip("/")
    if path.lower().endswith(".git"):
        path = path[:-4]
    path = re.sub(r"/{2,}", "/", path)
    if not path or any(part in {"", ".", ".."} for part in path.split("/")):
        raise ValidationError("Repository URI must identify a valid repository path.")
    encoded = "/".join(quote(part, safe="@:+,=~._-") for part in path.split("/"))
    canonical = urlunsplit((scheme, f"{user_info}{host}{port}", f"/{encoded}", "", ""))
    repository_key = f"{host}{port}/{path}".lower()
    display_name = "/".join(path.split("/")[-2:]) if "/" in path else path
    return RepositoryIdentity(
        original_uri=original,
        canonical_uri=canonical,
        repository_key=repository_key,
        host=host,
        display_name=display_name,
        provider=infer_provider(host),
    )


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str)


def config_hash(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def expected_tags(project_id: str, environment: str, settings: Settings) -> dict[str, str]:
    if environment not in {"dev", "prod"}:
        raise ValidationError("Environment must be dev or prod.")
    env_value = (
        str(settings.governance.get("dev_environment_value", "dev"))
        if environment == "dev"
        else str(settings.governance.get("prod_environment_value", "prod"))
    )
    return {
        settings.project_tag_key: project_id,
        settings.environment_tag_key: env_value,
    }


@dataclass(frozen=True)
class TagEvidenceEvaluation:
    passed: bool
    detail: str
    resource_count: int


def evaluate_tag_evidence(
    rows: Iterable[Mapping[str, Any]],
    *,
    project_id: str,
    environment: str,
    settings: Settings,
) -> TagEvidenceEvaluation:
    expected = expected_tags(project_id, environment, settings)
    evidence = [dict(row) for row in rows]
    if not evidence:
        return TagEvidenceEvaluation(False, "No resource tag evidence was submitted.", 0)

    failures: list[str] = []
    coverage: dict[tuple[str, str], set[str]] = {}
    seen: set[tuple[str, str, str]] = set()
    for row in evidence:
        resource_type = str(row.get("resource_type") or "").strip()
        identifier = str(row.get("resource_identifier") or "").strip()
        logical_name = str(row.get("logical_name") or identifier).strip()
        tag_key = str(row.get("tag_key") or "").strip()
        actual = str(row.get("actual_value") or "")
        expected_value = str(row.get("expected_value") or "")
        status = str(row.get("status") or row.get("tag_status") or "FAIL").upper()
        row_environment = str(row.get("environment") or environment).lower()
        if not resource_type or not identifier or not tag_key:
            failures.append("Tag evidence contains an empty resource type, identifier, or tag key.")
            continue
        unique = (resource_type, identifier, tag_key)
        if unique in seen:
            failures.append(f"Duplicate evidence for {resource_type} {identifier} tag {tag_key}.")
            continue
        seen.add(unique)
        if row_environment != environment:
            failures.append(f"{resource_type} {identifier} reported environment {row_environment!r}.")
        if tag_key not in expected:
            failures.append(f"{resource_type} {identifier} reported unexpected mandatory tag {tag_key!r}.")
            continue
        if expected_value != expected[tag_key]:
            failures.append(
                f"{resource_type} {identifier} expected value {expected_value!r} for {tag_key}; "
                f"registry requires {expected[tag_key]!r}."
            )
        if actual != expected[tag_key] or status not in {"PASS", "MANAGED"}:
            failures.append(
                f"{resource_type} {logical_name} has {tag_key}={actual!r}; expected {expected[tag_key]!r}."
            )
        coverage.setdefault((resource_type, identifier), set()).add(tag_key)

    required_keys = set(expected)
    for (resource_type, identifier), keys in coverage.items():
        missing = required_keys - keys
        if missing:
            failures.append(
                f"{resource_type} {identifier} is missing evidence for {', '.join(sorted(missing))}."
            )

    require_any = bool(settings.governance.get("require_at_least_one_governed_resource", True))
    if require_any and not coverage:
        failures.append("No governed resources were included in tag evidence.")

    detail = (
        f"Validated {len(evidence)} tag checks across {len(coverage)} governed resources."
        if not failures
        else "; ".join(dict.fromkeys(failures))
    )
    return TagEvidenceEvaluation(not failures, detail, len(coverage))
