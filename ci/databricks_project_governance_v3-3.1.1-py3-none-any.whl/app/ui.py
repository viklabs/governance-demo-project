from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app import __version__
from app.auth import actor_from_request
from app.governance import RELEASE_READY
from app.service import RegistryService

router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent / "templates"))
templates.env.filters["prettyjson"] = lambda value: json.dumps(
    value, indent=2, sort_keys=True, default=str
)


def _common(request: Request, *, title: str, active: str) -> dict[str, Any]:
    settings = request.app.state.settings
    service: RegistryService = request.app.state.service
    actor = actor_from_request(request, settings)
    return {
        "request": request,
        "app_version": __version__,
        "page_title": title,
        "active_page": active,
        "actor": actor,
        "is_admin": service.authorization.is_admin(actor),
        "is_approver": service.authorization.is_approver(actor),
        "support_contact": settings.app.get("support_contact", ""),
        "project_tag_key": settings.project_tag_key,
        "environment_tag_key": settings.environment_tag_key,
    }


@router.get("/", response_class=HTMLResponse)
def dashboard(request: Request) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    context = _common(request, title="Dashboard", active="dashboard")
    context["summary"] = service.dashboard()
    context["recent_releases"] = service.list_releases()[:8]
    context["recent_projects"] = service.list_projects()[:8]
    return templates.TemplateResponse(request, "dashboard.html", context)


@router.get("/projects", response_class=HTMLResponse)
def projects(request: Request) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    context = _common(request, title="Projects", active="projects")
    context["projects"] = service.list_projects()
    return templates.TemplateResponse(request, "projects.html", context)


@router.get("/projects/new", response_class=HTMLResponse)
def project_new(request: Request) -> HTMLResponse:
    settings = request.app.state.settings
    context = _common(request, title="Register project", active="projects")
    context["defaults"] = settings.raw.get("project_defaults", {})
    context["classifications"] = settings.raw.get("project_defaults", {}).get(
        "data_classifications", ["Internal"]
    )
    return templates.TemplateResponse(request, "project_new.html", context)


@router.get("/projects/{project_id}/edit", response_class=HTMLResponse)
def project_edit(request: Request, project_id: str) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    project = service.get_project(project_id)
    actor = actor_from_request(request, request.app.state.settings)
    service.authorization.require_admin(actor)
    context = _common(request, title=f"Edit {project.name}", active="projects")
    context["project"] = project
    context["classifications"] = request.app.state.settings.raw.get("project_defaults", {}).get(
        "data_classifications", ["Internal"]
    )
    context["validation_jobs"] = ", ".join(
        item.key for item in project.validation_resources if item.type == "job"
    )
    context["validation_pipelines"] = ", ".join(
        item.key for item in project.validation_resources if item.type == "pipeline"
    )
    context["additional_assets_json"] = json.dumps(
        [item.model_dump(mode="json") for item in project.additional_assets], indent=2
    )
    context["authorized_submitters"] = ", ".join(project.authorized_submitters)
    return templates.TemplateResponse(request, "project_edit.html", context)


@router.get("/projects/{project_id}", response_class=HTMLResponse)
def project_detail(request: Request, project_id: str) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    project = service.get_project(project_id)
    context = _common(request, title=project.name, active="projects")
    context["project"] = project
    context["releases"] = service.list_releases(project_id=project_id)
    context["bootstrap"] = {
        "bundle_variables": ["project_id", "environment_name", "catalog_name", "schema_name"],
        "required_tags": {
            "project_tag": "${var.project_id}",
            "environment": "${var.environment_name}",
        },
    }
    return templates.TemplateResponse(request, "project_detail.html", context)


@router.get("/releases", response_class=HTMLResponse)
def releases(request: Request) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    context = _common(request, title="Releases", active="releases")
    context["releases"] = service.list_releases()
    context["projects"] = [item for item in service.list_projects("ACTIVE")]
    return templates.TemplateResponse(request, "releases.html", context)


@router.get("/releases/{release_id}", response_class=HTMLResponse)
def release_detail(request: Request, release_id: str) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    value = service.release_detail(release_id)
    context = _common(request, title=release_id, active="releases")
    context.update(value)
    return templates.TemplateResponse(request, "release_detail.html", context)


@router.get("/approvals", response_class=HTMLResponse)
def approvals(request: Request) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    context = _common(request, title="Approvals", active="approvals")
    context["releases"] = service.list_releases(status=RELEASE_READY)
    return templates.TemplateResponse(request, "approvals.html", context)


@router.get("/audit", response_class=HTMLResponse)
def audit(request: Request) -> HTMLResponse:
    service: RegistryService = request.app.state.service
    context = _common(request, title="Audit", active="audit")
    context["events"] = service.list_audit(context["actor"], 1000)
    return templates.TemplateResponse(request, "audit.html", context)
