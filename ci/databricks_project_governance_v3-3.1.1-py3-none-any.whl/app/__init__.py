"""FastAPI application for simplified Databricks project governance v3."""

__version__ = "3.1.1"
