from __future__ import annotations

import json
from contextlib import contextmanager
from typing import Any, Iterator, Mapping, Sequence
from urllib.parse import urlparse

from app.governance import (
    DEV_DEPLOYED,
    DEV_FAILED,
    DEV_PENDING,
    PROD_DEPLOYED,
    PROD_DEPLOYING,
    PROD_FAILED,
    PROD_PENDING,
    PROJECT_ACTIVE,
    PROJECT_PENDING,
    PROJECT_REJECTED,
    PROJECT_RETIRED,
    PROJECT_SUSPENDED,
    RELEASE_APPROVED,
    RELEASE_CHECKS_FAILED,
    RELEASE_DEPLOYED,
    RELEASE_DEPLOYING,
    RELEASE_FAILED,
    RELEASE_READY,
    RELEASE_REJECTED,
    RELEASE_VALIDATING,
    ConflictError,
    NotFoundError,
    ValidationError,
    config_hash,
    evaluate_tag_evidence,
    generate_id,
    normalize_repository_uri,
    utc_now,
)
from app.models import CicdConfig, DevValidationReport, ProductionReport, ProjectCreate, ProjectUpdate
from app.settings import Settings, SettingsError




TABLE_COLUMNS: dict[str, tuple[str, ...]] = {
    "projects": (
        "project_id", "name", "team_name", "technical_owner_email",
        "business_owner_email", "description", "lifecycle_status",
        "data_classification", "decision_comment", "created_at", "created_by",
        "updated_at", "updated_by",
    ),
    "project_cicd": (
        "project_id", "repository_uri", "repository_key", "repository_display_name",
        "source_provider", "bundle_path", "dev_target", "prod_target",
        "dev_catalog", "dev_schema", "prod_catalog", "prod_schema",
        "validation_resources_json", "additional_assets_json",
        "authorized_submitters_json", "config_hash", "created_at", "created_by",
        "updated_at", "updated_by",
    ),
    "releases": (
        "release_id", "project_id", "repository_uri", "repository_key",
        "source_revision", "source_ref", "config_hash", "release_status",
        "dev_deployment_status", "dev_tag_check_passed", "dev_tag_check_detail",
        "dev_pipeline_run_url", "dev_deployed_at", "requested_at", "requested_by",
        "approved_at", "approved_by", "decision_comment",
        "prod_deployment_status", "prod_tag_check_passed", "prod_tag_check_detail",
        "prod_pipeline_run_url", "prod_deployed_at", "deployment_message",
        "updated_at", "updated_by",
    ),
    "resource_tags": (
        "tag_record_id", "release_id", "project_id", "environment",
        "resource_type", "logical_name", "resource_identifier", "tag_key",
        "expected_value", "actual_value", "verification_mode", "tag_status",
        "detail", "checked_at", "checked_by",
    ),
    "audit": (
        "event_id", "entity_type", "entity_id", "project_id", "release_id",
        "event_type", "actor", "detail_json", "created_at",
    ),
}

class RegistryDatabase:
    """Delta-table repository accessed through a Databricks SQL warehouse."""

    def __init__(self, settings: Settings):
        self.settings = settings
        try:
            from databricks.sdk.core import Config as DatabricksConfig
        except ImportError as exc:  # pragma: no cover - deployment dependency
            raise SettingsError("databricks-sdk is required to run the registry App.") from exc
        self.sdk_config = DatabricksConfig()
        if not self.sdk_config.host:
            raise SettingsError(
                "DATABRICKS_HOST is unavailable. Databricks Apps injects it automatically; "
                "set it explicitly for local execution."
            )
        parsed = urlparse(self.sdk_config.host)
        self.server_hostname = parsed.hostname or self.sdk_config.host.replace("https://", "").strip("/")
        self.http_path = f"/sql/1.0/warehouses/{settings.warehouse_id}"

    @contextmanager
    def connection(self) -> Iterator[Any]:
        from databricks import sql

        connection = sql.connect(
            server_hostname=self.server_hostname,
            http_path=self.http_path,
            credentials_provider=lambda: self.sdk_config.authenticate,
            catalog=str(self.settings.database["catalog"]),
            schema=str(self.settings.database["schema"]),
            _use_arrow_native_complex_types=False,
        )
        try:
            yield connection
        finally:
            connection.close()

    @staticmethod
    def _dict_rows(cursor: Any, rows: Sequence[Any]) -> list[dict[str, Any]]:
        columns = [item[0] if isinstance(item, tuple) else item.name for item in (cursor.description or [])]
        return [dict(zip(columns, row, strict=False)) for row in rows]

    def execute(self, statement: str, parameters: Mapping[str, Any] | None = None) -> None:
        with self.connection() as connection, connection.cursor() as cursor:
            cursor.execute(statement, parameters or {})

    def fetch_all(self, statement: str, parameters: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        with self.connection() as connection, connection.cursor() as cursor:
            cursor.execute(statement, parameters or {})
            return self._dict_rows(cursor, cursor.fetchall())

    def fetch_one(self, statement: str, parameters: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        rows = self.fetch_all(statement, parameters)
        return rows[0] if rows else None

    def scalar(self, statement: str, parameters: Mapping[str, Any] | None = None) -> Any:
        row = self.fetch_one(statement, parameters)
        return next(iter(row.values())) if row else None

    def health(self) -> dict[str, Any]:
        try:
            return {
                "ok": True,
                "backend": "databricks-delta",
                "catalog": self.settings.database["catalog"],
                "schema": self.settings.database["schema"],
                "current_user": str(self.scalar("SELECT current_user() AS current_user") or "unknown"),
            }
        except Exception as exc:
            return {
                "ok": False,
                "backend": "databricks-delta",
                "catalog": self.settings.database.get("catalog"),
                "schema": self.settings.database.get("schema"),
                "error": str(exc),
            }

    def ensure_tables(self) -> None:
        if not bool(self.settings.database.get("auto_create_tables", False)):
            return
        for statement in self._ddl_statements():
            self.execute(statement)

    def _ddl_statements(self) -> tuple[str, ...]:
        return (
            f"""
            CREATE TABLE IF NOT EXISTS {self.settings.table('projects')} (
              project_id STRING, name STRING, team_name STRING,
              technical_owner_email STRING, business_owner_email STRING,
              description STRING, lifecycle_status STRING, data_classification STRING,
              decision_comment STRING, created_at TIMESTAMP, created_by STRING,
              updated_at TIMESTAMP, updated_by STRING
            ) USING DELTA
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self.settings.table('project_cicd')} (
              project_id STRING, repository_uri STRING, repository_key STRING,
              repository_display_name STRING, source_provider STRING, bundle_path STRING,
              dev_target STRING, prod_target STRING, dev_catalog STRING, dev_schema STRING,
              prod_catalog STRING, prod_schema STRING, validation_resources_json STRING,
              additional_assets_json STRING, authorized_submitters_json STRING,
              config_hash STRING, created_at TIMESTAMP, created_by STRING,
              updated_at TIMESTAMP, updated_by STRING
            ) USING DELTA
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self.settings.table('releases')} (
              release_id STRING, project_id STRING, repository_uri STRING, repository_key STRING,
              source_revision STRING, source_ref STRING, config_hash STRING, release_status STRING,
              dev_deployment_status STRING, dev_tag_check_passed BOOLEAN,
              dev_tag_check_detail STRING, dev_pipeline_run_url STRING, dev_deployed_at TIMESTAMP,
              requested_at TIMESTAMP, requested_by STRING, approved_at TIMESTAMP,
              approved_by STRING, decision_comment STRING, prod_deployment_status STRING,
              prod_tag_check_passed BOOLEAN, prod_tag_check_detail STRING,
              prod_pipeline_run_url STRING, prod_deployed_at TIMESTAMP,
              deployment_message STRING, updated_at TIMESTAMP, updated_by STRING
            ) USING DELTA
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self.settings.table('resource_tags')} (
              tag_record_id STRING, release_id STRING, project_id STRING, environment STRING,
              resource_type STRING, logical_name STRING, resource_identifier STRING,
              tag_key STRING, expected_value STRING, actual_value STRING,
              verification_mode STRING, tag_status STRING, detail STRING,
              checked_at TIMESTAMP, checked_by STRING
            ) USING DELTA
            """,
            f"""
            CREATE TABLE IF NOT EXISTS {self.settings.table('audit')} (
              event_id STRING, entity_type STRING, entity_id STRING, project_id STRING,
              release_id STRING, event_type STRING, actor STRING, detail_json STRING,
              created_at TIMESTAMP
            ) USING DELTA
            """,
        )

    def table_columns(self, key: str) -> tuple[str, ...]:
        rows = self.fetch_all(f"DESCRIBE TABLE {self.settings.table(key)}")
        columns: list[str] = []
        for row in rows:
            name = str(row.get("col_name") or row.get("column_name") or "").strip()
            if not name or name.startswith("#"):
                break
            columns.append(name)
        return tuple(columns)

    def validate_schema(self) -> None:
        for key, expected in TABLE_COLUMNS.items():
            actual = self.table_columns(key)
            if actual != expected:
                raise SettingsError(
                    f"Registry table {self.settings.raw_table_name(key)} has columns {actual}; "
                    f"expected {expected}. Run sql/setup.sql in a clean schema or apply a reviewed migration."
                )

    @staticmethod
    def _json(value: Any) -> str:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)

    @staticmethod
    def _load_json(value: Any, default: Any) -> Any:
        if value in (None, ""):
            return default
        if isinstance(value, (dict, list, tuple)):
            return value
        try:
            return json.loads(str(value))
        except json.JSONDecodeError:
            return default

    def _decode_project(self, row: Mapping[str, Any]) -> dict[str, Any]:
        value = dict(row)
        value["validation_resources"] = tuple(
            self._load_json(value.pop("validation_resources_json", "[]"), [])
        )
        value["additional_assets"] = tuple(
            self._load_json(value.pop("additional_assets_json", "[]"), [])
        )
        value["authorized_submitters"] = tuple(
            str(item).lower()
            for item in self._load_json(value.pop("authorized_submitters_json", "[]"), [])
        )
        return value

    @staticmethod
    def _cicd_snapshot(cicd: CicdConfig) -> dict[str, Any]:
        identity = normalize_repository_uri(cicd.repository_uri)
        return {
            "repository_uri": identity.canonical_uri,
            "repository_key": identity.repository_key,
            "bundle_path": cicd.bundle_path,
            "dev_target": cicd.dev_target,
            "prod_target": cicd.prod_target,
            "dev_catalog": cicd.dev_catalog,
            "dev_schema": cicd.dev_schema,
            "prod_catalog": cicd.prod_catalog,
            "prod_schema": cicd.prod_schema,
            "validation_resources": [item.model_dump(mode="json") for item in cicd.validation_resources],
            "additional_assets": [item.model_dump(mode="json") for item in cicd.additional_assets],
            "authorized_submitters": list(cicd.authorized_submitters),
        }

    def audit(
        self,
        *,
        event_type: str,
        entity_type: str,
        entity_id: str,
        actor: str,
        project_id: str = "",
        release_id: str = "",
        detail: Mapping[str, Any] | None = None,
    ) -> None:
        self.execute(
            f"""
            INSERT INTO {self.settings.table('audit')} (
              event_id, entity_type, entity_id, project_id, release_id,
              event_type, actor, detail_json, created_at
            ) VALUES (
              :event_id, :entity_type, :entity_id, :project_id, :release_id,
              :event_type, :actor, :detail_json, :created_at
            )
            """,
            {
                "event_id": generate_id("EVT", 14),
                "entity_type": entity_type,
                "entity_id": entity_id,
                "project_id": project_id,
                "release_id": release_id,
                "event_type": event_type,
                "actor": actor,
                "detail_json": self._json(detail or {}),
                "created_at": utc_now(),
            },
        )

    # Projects -----------------------------------------------------------------
    def create_project(self, payload: ProjectCreate, actor: str, *, active: bool) -> dict[str, Any]:
        identity = normalize_repository_uri(payload.cicd.repository_uri)
        if self.fetch_one(
            f"SELECT project_id FROM {self.settings.table('project_cicd')} WHERE repository_key = :key LIMIT 1",
            {"key": identity.repository_key},
        ):
            raise ConflictError("This repository is already registered to a project.")
        if self.fetch_one(
            f"SELECT project_id FROM {self.settings.table('projects')} WHERE lower(name) = lower(:name) LIMIT 1",
            {"name": payload.name},
        ):
            raise ConflictError("A project with this name already exists.")

        project_id = generate_id(
            str(self.settings.governance.get("project_id_prefix", "PRJ")),
            int(self.settings.governance.get("project_id_length", 10)),
        )
        now = utc_now()
        status = PROJECT_ACTIVE if active else PROJECT_PENDING
        snapshot = self._cicd_snapshot(payload.cicd)
        hash_value = config_hash(snapshot)
        self.execute(
            f"""
            INSERT INTO {self.settings.table('projects')} (
              project_id, name, team_name, technical_owner_email, business_owner_email,
              description, lifecycle_status, data_classification, decision_comment,
              created_at, created_by, updated_at, updated_by
            ) VALUES (
              :project_id, :name, :team_name, :technical_owner, :business_owner,
              :description, :status, :classification, '', :created_at, :created_by,
              :updated_at, :updated_by
            )
            """,
            {
                "project_id": project_id,
                "name": payload.name,
                "team_name": payload.team_name,
                "technical_owner": payload.technical_owner_email,
                "business_owner": payload.business_owner_email,
                "description": payload.description,
                "status": status,
                "classification": payload.data_classification,
                "created_at": now,
                "created_by": actor,
                "updated_at": now,
                "updated_by": actor,
            },
        )
        self.execute(
            f"""
            INSERT INTO {self.settings.table('project_cicd')} (
              project_id, repository_uri, repository_key, repository_display_name,
              source_provider, bundle_path, dev_target, prod_target, dev_catalog,
              dev_schema, prod_catalog, prod_schema, validation_resources_json,
              additional_assets_json, authorized_submitters_json, config_hash,
              created_at, created_by, updated_at, updated_by
            ) VALUES (
              :project_id, :repository_uri, :repository_key, :display_name,
              :provider, :bundle_path, :dev_target, :prod_target, :dev_catalog,
              :dev_schema, :prod_catalog, :prod_schema, :validation_resources,
              :additional_assets, :authorized_submitters, :config_hash,
              :created_at, :created_by, :updated_at, :updated_by
            )
            """,
            {
                "project_id": project_id,
                "repository_uri": identity.canonical_uri,
                "repository_key": identity.repository_key,
                "display_name": identity.display_name,
                "provider": identity.provider,
                "bundle_path": payload.cicd.bundle_path,
                "dev_target": payload.cicd.dev_target,
                "prod_target": payload.cicd.prod_target,
                "dev_catalog": payload.cicd.dev_catalog,
                "dev_schema": payload.cicd.dev_schema,
                "prod_catalog": payload.cicd.prod_catalog,
                "prod_schema": payload.cicd.prod_schema,
                "validation_resources": self._json(snapshot["validation_resources"]),
                "additional_assets": self._json(snapshot["additional_assets"]),
                "authorized_submitters": self._json(snapshot["authorized_submitters"]),
                "config_hash": hash_value,
                "created_at": now,
                "created_by": actor,
                "updated_at": now,
                "updated_by": actor,
            },
        )
        self.audit(
            event_type="PROJECT_REGISTERED",
            entity_type="PROJECT",
            entity_id=project_id,
            project_id=project_id,
            actor=actor,
            detail={"status": status, "repository": identity.canonical_uri},
        )
        return self.get_project(project_id)

    def _project_query(self) -> str:
        return f"""
        SELECT p.*, c.repository_uri, c.repository_key, c.repository_display_name,
               c.source_provider, c.bundle_path, c.dev_target, c.prod_target,
               c.dev_catalog, c.dev_schema, c.prod_catalog, c.prod_schema,
               c.validation_resources_json, c.additional_assets_json,
               c.authorized_submitters_json, c.config_hash
        FROM {self.settings.table('projects')} p
        INNER JOIN {self.settings.table('project_cicd')} c ON p.project_id = c.project_id
        """

    def get_project(self, project_id: str) -> dict[str, Any]:
        row = self.fetch_one(
            self._project_query() + " WHERE p.project_id = :project_id LIMIT 1",
            {"project_id": project_id},
        )
        if not row:
            raise NotFoundError("Project not found.")
        return self._decode_project(row)

    def get_project_by_repository(self, repository_uri: str) -> dict[str, Any]:
        key = normalize_repository_uri(repository_uri).repository_key
        row = self.fetch_one(
            self._project_query() + " WHERE c.repository_key = :key LIMIT 1",
            {"key": key},
        )
        if not row:
            raise NotFoundError("No project is registered for this repository.")
        return self._decode_project(row)

    def list_projects(self, status: str | None = None) -> list[dict[str, Any]]:
        statement = self._project_query()
        parameters: dict[str, Any] = {}
        if status:
            statement += " WHERE p.lifecycle_status = :status"
            parameters["status"] = status
        statement += " ORDER BY p.updated_at DESC, p.name"
        return [self._decode_project(row) for row in self.fetch_all(statement, parameters)]

    def update_project(self, project_id: str, payload: ProjectUpdate, actor: str) -> dict[str, Any]:
        current = self.get_project(project_id)
        # Validate name and repository uniqueness before writing either table. The two Delta
        # tables are intentionally simple and are updated separately, so all predictable
        # validation must happen before the first write.
        if payload.name is not None and payload.name.strip().lower() != str(current["name"]).strip().lower():
            conflict = self.fetch_one(
                f"""
                SELECT project_id FROM {self.settings.table('projects')}
                WHERE lower(name) = lower(:name) AND project_id <> :project_id LIMIT 1
                """,
                {"name": payload.name, "project_id": project_id},
            )
            if conflict:
                raise ConflictError("A project with this name already exists.")

        cicd_update: dict[str, Any] | None = None
        if payload.cicd is not None:
            deploying = self.fetch_one(
                f"""
                SELECT release_id FROM {self.settings.table('releases')}
                WHERE project_id = :project_id AND release_status = :status LIMIT 1
                """,
                {"project_id": project_id, "status": RELEASE_DEPLOYING},
            )
            if deploying:
                raise ConflictError(
                    "Project delivery configuration cannot change while a production deployment is in progress."
                )
            identity = normalize_repository_uri(payload.cicd.repository_uri)
            conflict = self.fetch_one(
                f"""
                SELECT project_id FROM {self.settings.table('project_cicd')}
                WHERE repository_key = :key AND project_id <> :project_id LIMIT 1
                """,
                {"key": identity.repository_key, "project_id": project_id},
            )
            if conflict:
                raise ConflictError("This repository is already registered to another project.")
            snapshot = self._cicd_snapshot(payload.cicd)
            cicd_update = {
                "identity": identity,
                "snapshot": snapshot,
                "config_hash": config_hash(snapshot),
            }

        now = utc_now()
        project_values = {
            "name": payload.name if payload.name is not None else current["name"],
            "team_name": payload.team_name if payload.team_name is not None else current["team_name"],
            "technical_owner": (
                payload.technical_owner_email
                if payload.technical_owner_email is not None
                else current["technical_owner_email"]
            ),
            "business_owner": (
                payload.business_owner_email
                if payload.business_owner_email is not None
                else current["business_owner_email"]
            ),
            "description": payload.description if payload.description is not None else current["description"],
            "classification": (
                payload.data_classification
                if payload.data_classification is not None
                else current["data_classification"]
            ),
        }
        self.execute(
            f"""
            UPDATE {self.settings.table('projects')}
            SET name = :name, team_name = :team_name,
                technical_owner_email = :technical_owner,
                business_owner_email = :business_owner,
                description = :description, data_classification = :classification,
                updated_at = :updated_at, updated_by = :actor
            WHERE project_id = :project_id
            """,
            {**project_values, "updated_at": now, "actor": actor, "project_id": project_id},
        )
        if payload.cicd is not None and cicd_update is not None:
            identity = cicd_update["identity"]
            snapshot = cicd_update["snapshot"]
            hash_value = cicd_update["config_hash"]
            self.execute(
                f"""
                UPDATE {self.settings.table('project_cicd')}
                SET repository_uri = :repository_uri, repository_key = :repository_key,
                    repository_display_name = :display_name, source_provider = :provider,
                    bundle_path = :bundle_path, dev_target = :dev_target,
                    prod_target = :prod_target, dev_catalog = :dev_catalog,
                    dev_schema = :dev_schema, prod_catalog = :prod_catalog,
                    prod_schema = :prod_schema,
                    validation_resources_json = :validation_resources,
                    additional_assets_json = :additional_assets,
                    authorized_submitters_json = :authorized_submitters,
                    config_hash = :config_hash, updated_at = :updated_at, updated_by = :actor
                WHERE project_id = :project_id
                """,
                {
                    "repository_uri": identity.canonical_uri,
                    "repository_key": identity.repository_key,
                    "display_name": identity.display_name,
                    "provider": identity.provider,
                    "bundle_path": payload.cicd.bundle_path,
                    "dev_target": payload.cicd.dev_target,
                    "prod_target": payload.cicd.prod_target,
                    "dev_catalog": payload.cicd.dev_catalog,
                    "dev_schema": payload.cicd.dev_schema,
                    "prod_catalog": payload.cicd.prod_catalog,
                    "prod_schema": payload.cicd.prod_schema,
                    "validation_resources": self._json(snapshot["validation_resources"]),
                    "additional_assets": self._json(snapshot["additional_assets"]),
                    "authorized_submitters": self._json(snapshot["authorized_submitters"]),
                    "config_hash": hash_value,
                    "updated_at": now,
                    "actor": actor,
                    "project_id": project_id,
                },
            )
            invalidation_detail = (
                "Project delivery configuration changed after release creation. "
                "Create and validate a fresh release."
            )
            self.execute(
                f"""
                UPDATE {self.settings.table('releases')}
                SET release_status = :failed_status,
                    dev_deployment_status = :dev_failed,
                    dev_tag_check_passed = false,
                    dev_tag_check_detail = :detail,
                    approved_at = NULL, approved_by = NULL,
                    decision_comment = '',
                    prod_deployment_status = :prod_pending,
                    prod_tag_check_passed = NULL,
                    prod_tag_check_detail = '',
                    deployment_message = :detail,
                    updated_at = :updated_at, updated_by = :actor
                WHERE project_id = :project_id
                  AND release_status IN (
                    'VALIDATING','CHECKS_FAILED','READY_FOR_APPROVAL','APPROVED'
                  )
                """,
                {
                    "failed_status": RELEASE_CHECKS_FAILED,
                    "dev_failed": DEV_FAILED,
                    "detail": invalidation_detail,
                    "prod_pending": PROD_PENDING,
                    "updated_at": now,
                    "actor": actor,
                    "project_id": project_id,
                },
            )
        self.audit(
            event_type="PROJECT_UPDATED",
            entity_type="PROJECT",
            entity_id=project_id,
            project_id=project_id,
            actor=actor,
            detail={"cicd_changed": payload.cicd is not None},
        )
        return self.get_project(project_id)

    def decide_project(self, project_id: str, *, approve: bool, actor: str, comment: str) -> dict[str, Any]:
        project = self.get_project(project_id)
        if project["lifecycle_status"] != PROJECT_PENDING:
            raise ConflictError("Only a pending project can be approved or rejected.")
        status = PROJECT_ACTIVE if approve else PROJECT_REJECTED
        now = utc_now()
        self.execute(
            f"""
            UPDATE {self.settings.table('projects')}
            SET lifecycle_status = :status, decision_comment = :comment,
                updated_at = :updated_at, updated_by = :actor
            WHERE project_id = :project_id AND lifecycle_status = :expected
            """,
            {
                "status": status,
                "comment": comment[:4000],
                "updated_at": now,
                "actor": actor,
                "project_id": project_id,
                "expected": PROJECT_PENDING,
            },
        )
        updated = self.get_project(project_id)
        if updated["lifecycle_status"] != status:
            raise ConflictError("Project changed concurrently; refresh and try again.")
        self.audit(
            event_type="PROJECT_APPROVED" if approve else "PROJECT_REJECTED",
            entity_type="PROJECT",
            entity_id=project_id,
            project_id=project_id,
            actor=actor,
            detail={"comment": comment},
        )
        return updated

    def set_project_status(self, project_id: str, status: str, actor: str, comment: str) -> dict[str, Any]:
        project = self.get_project(project_id)
        if status not in {PROJECT_ACTIVE, PROJECT_SUSPENDED, PROJECT_RETIRED}:
            raise ValidationError("Project status must be ACTIVE, SUSPENDED, or RETIRED.")
        self.execute(
            f"""
            UPDATE {self.settings.table('projects')}
            SET lifecycle_status = :status, decision_comment = :comment,
                updated_at = :updated_at, updated_by = :actor
            WHERE project_id = :project_id
            """,
            {
                "status": status,
                "comment": comment[:4000],
                "updated_at": utc_now(),
                "actor": actor,
                "project_id": project_id,
            },
        )
        self.audit(
            event_type="PROJECT_STATUS_CHANGED",
            entity_type="PROJECT",
            entity_id=project_id,
            project_id=project_id,
            actor=actor,
            detail={"from": project["lifecycle_status"], "to": status, "comment": comment},
        )
        return self.get_project(project_id)

    # Releases -----------------------------------------------------------------
    def create_release(
        self,
        project_id: str,
        source_revision: str,
        source_ref: str,
        pipeline_run_url: str,
        actor: str,
    ) -> dict[str, Any]:
        project = self.get_project(project_id)
        if project["lifecycle_status"] != PROJECT_ACTIVE:
            raise ConflictError("Only an active project can create a release.")
        existing = self.fetch_one(
            f"""
            SELECT release_id, release_status FROM {self.settings.table('releases')}
            WHERE project_id = :project_id AND source_revision = :revision
              AND config_hash = :config_hash
              AND release_status IN ('VALIDATING','READY_FOR_APPROVAL','APPROVED','DEPLOYING','DEPLOYED')
            LIMIT 1
            """,
            {
                "project_id": project_id,
                "revision": source_revision,
                "config_hash": project["config_hash"],
            },
        )
        if existing:
            raise ConflictError(
                f"Revision already has active release {existing['release_id']} in status {existing['release_status']}."
            )
        release_id = generate_id(
            str(self.settings.governance.get("release_id_prefix", "REL")),
            int(self.settings.governance.get("release_id_length", 12)),
        )
        now = utc_now()
        self.execute(
            f"""
            INSERT INTO {self.settings.table('releases')} (
              release_id, project_id, repository_uri, repository_key, source_revision,
              source_ref, config_hash, release_status, dev_deployment_status,
              dev_tag_check_passed, dev_tag_check_detail, dev_pipeline_run_url,
              dev_deployed_at, requested_at, requested_by, approved_at, approved_by,
              decision_comment, prod_deployment_status, prod_tag_check_passed,
              prod_tag_check_detail, prod_pipeline_run_url, prod_deployed_at,
              deployment_message, updated_at, updated_by
            ) VALUES (
              :release_id, :project_id, :repository_uri, :repository_key, :source_revision,
              :source_ref, :config_hash, :release_status, :dev_status,
              NULL, '', :pipeline_url, NULL, :requested_at, :requested_by,
              NULL, NULL, '', :prod_status, NULL, '', '', NULL, '', :updated_at, :updated_by
            )
            """,
            {
                "release_id": release_id,
                "project_id": project_id,
                "repository_uri": project["repository_uri"],
                "repository_key": project["repository_key"],
                "source_revision": source_revision,
                "source_ref": source_ref,
                "config_hash": project["config_hash"],
                "release_status": RELEASE_VALIDATING,
                "dev_status": DEV_PENDING,
                "pipeline_url": pipeline_run_url,
                "requested_at": now,
                "requested_by": actor,
                "prod_status": PROD_PENDING,
                "updated_at": now,
                "updated_by": actor,
            },
        )
        self.audit(
            event_type="RELEASE_CREATED",
            entity_type="RELEASE",
            entity_id=release_id,
            project_id=project_id,
            release_id=release_id,
            actor=actor,
            detail={"source_revision": source_revision, "source_ref": source_ref},
        )
        return self.get_release(release_id)

    def _release_query(self) -> str:
        return f"""
        SELECT r.*, p.name AS project_name, p.lifecycle_status,
               c.bundle_path, c.dev_target, c.prod_target, c.dev_catalog,
               c.dev_schema, c.prod_catalog, c.prod_schema,
               c.validation_resources_json, c.additional_assets_json,
               c.authorized_submitters_json, c.config_hash AS current_config_hash,
               c.repository_uri AS current_repository_uri,
               c.repository_key AS current_repository_key,
               p.technical_owner_email, p.business_owner_email, p.created_by
        FROM {self.settings.table('releases')} r
        INNER JOIN {self.settings.table('projects')} p ON r.project_id = p.project_id
        INNER JOIN {self.settings.table('project_cicd')} c ON r.project_id = c.project_id
        """

    def _decode_release(self, row: Mapping[str, Any]) -> dict[str, Any]:
        value = dict(row)
        value["validation_resources"] = tuple(
            self._load_json(value.pop("validation_resources_json", "[]"), [])
        )
        value["additional_assets"] = tuple(
            self._load_json(value.pop("additional_assets_json", "[]"), [])
        )
        value["authorized_submitters"] = tuple(
            str(item).lower()
            for item in self._load_json(value.pop("authorized_submitters_json", "[]"), [])
        )
        return value

    def get_release(self, release_id: str) -> dict[str, Any]:
        row = self.fetch_one(
            self._release_query() + " WHERE r.release_id = :release_id LIMIT 1",
            {"release_id": release_id},
        )
        if not row:
            raise NotFoundError("Release not found.")
        return self._decode_release(row)

    def list_releases(self, status: str | None = None, project_id: str | None = None) -> list[dict[str, Any]]:
        clauses: list[str] = []
        parameters: dict[str, Any] = {}
        if status:
            clauses.append("r.release_status = :status")
            parameters["status"] = status
        if project_id:
            clauses.append("r.project_id = :project_id")
            parameters["project_id"] = project_id
        statement = self._release_query()
        if clauses:
            statement += " WHERE " + " AND ".join(clauses)
        statement += " ORDER BY r.updated_at DESC, r.requested_at DESC"
        return [self._decode_release(row) for row in self.fetch_all(statement, parameters)]

    def _assert_release_identity(
        self,
        release: Mapping[str, Any],
        *,
        repository_uri: str,
        source_revision: str,
        require_current_config: bool = True,
    ) -> None:
        identity = normalize_repository_uri(repository_uri)
        if identity.repository_key != str(release["repository_key"]).lower():
            raise ValidationError("CI repository does not match the repository stored on the release.")
        if source_revision.lower() != str(release["source_revision"]).lower():
            raise ValidationError("CI source revision does not match the release.")
        if str(release["lifecycle_status"]) != PROJECT_ACTIVE:
            raise ConflictError("Project is not active.")
        if require_current_config and str(release["config_hash"]) != str(release["current_config_hash"]):
            raise ConflictError(
                "Project deployment configuration changed after release creation. Create and validate a new release."
            )
        if str(release["repository_key"]) != str(release["current_repository_key"]):
            raise ConflictError("Project repository changed after release creation. Create a new release.")

    def ci_release_info(self, release_id: str, repository_uri: str, source_revision: str) -> dict[str, Any]:
        release = self.get_release(release_id)
        self._assert_release_identity(
            release,
            repository_uri=repository_uri,
            source_revision=source_revision,
        )
        return release

    def _replace_tag_results(
        self,
        release_id: str,
        project_id: str,
        environment: str,
        rows: Sequence[Mapping[str, Any]],
        actor: str,
    ) -> None:
        self.execute(
            f"DELETE FROM {self.settings.table('resource_tags')} "
            "WHERE release_id = :release_id AND environment = :environment",
            {"release_id": release_id, "environment": environment},
        )
        now = utc_now()
        for row in rows:
            self.execute(
                f"""
                INSERT INTO {self.settings.table('resource_tags')} (
                  tag_record_id, release_id, project_id, environment, resource_type,
                  logical_name, resource_identifier, tag_key, expected_value,
                  actual_value, verification_mode, tag_status, detail, checked_at, checked_by
                ) VALUES (
                  :tag_record_id, :release_id, :project_id, :environment, :resource_type,
                  :logical_name, :resource_identifier, :tag_key, :expected_value,
                  :actual_value, :verification_mode, :tag_status, :detail, :checked_at, :checked_by
                )
                """,
                {
                    "tag_record_id": generate_id("TAG", 14),
                    "release_id": release_id,
                    "project_id": project_id,
                    "environment": environment,
                    "resource_type": str(row.get("resource_type") or ""),
                    "logical_name": str(row.get("logical_name") or ""),
                    "resource_identifier": str(row.get("resource_identifier") or ""),
                    "tag_key": str(row.get("tag_key") or ""),
                    "expected_value": str(row.get("expected_value") or ""),
                    "actual_value": str(row.get("actual_value") or ""),
                    "verification_mode": str(row.get("verification_mode") or ""),
                    "tag_status": str(row.get("status") or row.get("tag_status") or "FAIL"),
                    "detail": str(row.get("detail") or "")[:12000],
                    "checked_at": now,
                    "checked_by": actor,
                },
            )

    def _stored_tag_evaluation(
        self,
        release: Mapping[str, Any],
        environment: str,
    ) -> Any:
        rows = [
            row
            for row in self.list_resource_tags(str(release["release_id"]))
            if str(row.get("environment") or "").lower() == environment
        ]
        return evaluate_tag_evidence(
            rows,
            project_id=str(release["project_id"]),
            environment=environment,
            settings=self.settings,
        )

    def record_dev_validation(
        self,
        release_id: str,
        report: DevValidationReport,
        actor: str,
    ) -> dict[str, Any]:
        release = self.get_release(release_id)
        self._assert_release_identity(
            release,
            repository_uri=report.repository_uri,
            source_revision=report.source_revision,
        )
        rows = [item.model_dump(mode="json") for item in report.tag_results]
        tag_evaluation = evaluate_tag_evidence(
            rows,
            project_id=release["project_id"],
            environment="dev",
            settings=self.settings,
        )
        incoming_passed = all(
            (
                report.dev_bundle_valid,
                report.prod_bundle_preflight_valid,
                report.deployment_succeeded,
                report.workload_succeeded,
                tag_evaluation.passed,
            )
        )
        if release["release_status"] == RELEASE_READY:
            stored_evaluation = self._stored_tag_evaluation(release, "dev")
            if incoming_passed and stored_evaluation.passed:
                return release
            raise ConflictError(
                "A READY_FOR_APPROVAL release is immutable. Create a new release if validation evidence changed."
            )
        if release["release_status"] not in {RELEASE_VALIDATING, RELEASE_CHECKS_FAILED}:
            raise ConflictError("Dev validation can update only a validating or failed release.")
        passed = incoming_passed
        status = RELEASE_READY if passed else RELEASE_CHECKS_FAILED
        dev_status = DEV_DEPLOYED if passed else DEV_FAILED
        detail = " | ".join(item for item in (report.detail.strip(), tag_evaluation.detail) if item)
        now = utc_now()
        self._replace_tag_results(release_id, release["project_id"], "dev", rows, actor)
        self.execute(
            f"""
            UPDATE {self.settings.table('releases')}
            SET release_status = :release_status,
                dev_deployment_status = :dev_status,
                dev_tag_check_passed = :tag_passed,
                dev_tag_check_detail = :detail,
                dev_pipeline_run_url = :run_url,
                dev_deployed_at = :deployed_at,
                approved_at = NULL, approved_by = NULL, decision_comment = '',
                updated_at = :updated_at, updated_by = :actor
            WHERE release_id = :release_id AND release_status = :expected_status
            """,
            {
                "release_status": status,
                "dev_status": dev_status,
                "tag_passed": tag_evaluation.passed,
                "detail": detail[:12000],
                "run_url": report.run_url,
                "deployed_at": now,
                "updated_at": now,
                "actor": actor,
                "release_id": release_id,
                "expected_status": release["release_status"],
            },
        )
        updated = self.get_release(release_id)
        if updated["release_status"] != status:
            raise ConflictError("Release changed concurrently while dev validation was being recorded.")
        self.audit(
            event_type="DEV_VALIDATION_PASSED" if passed else "DEV_VALIDATION_FAILED",
            entity_type="RELEASE",
            entity_id=release_id,
            project_id=release["project_id"],
            release_id=release_id,
            actor=actor,
            detail={
                "detail": detail,
                "run_url": report.run_url,
                "dev_bundle_valid": report.dev_bundle_valid,
                "prod_bundle_preflight_valid": report.prod_bundle_preflight_valid,
                "deployment_succeeded": report.deployment_succeeded,
                "workload_succeeded": report.workload_succeeded,
            },
        )
        return updated

    def decide_release(self, release_id: str, *, approve: bool, actor: str, comment: str) -> dict[str, Any]:
        release = self.get_release(release_id)
        if release["release_status"] != RELEASE_READY:
            raise ConflictError("Only a release in READY_FOR_APPROVAL can be decided.")
        if release["dev_deployment_status"] != DEV_DEPLOYED or not bool(release["dev_tag_check_passed"]):
            raise ConflictError("The exact release has not passed dev deployment and tag validation.")
        stored_evaluation = self._stored_tag_evaluation(release, "dev")
        if not stored_evaluation.passed:
            raise ConflictError(
                "Stored dev tag evidence is incomplete or no longer supports approval: "
                + stored_evaluation.detail
            )
        self._assert_release_identity(
            release,
            repository_uri=release["repository_uri"],
            source_revision=release["source_revision"],
        )
        status = RELEASE_APPROVED if approve else RELEASE_REJECTED
        now = utc_now()
        self.execute(
            f"""
            UPDATE {self.settings.table('releases')}
            SET release_status = :status, approved_at = :approved_at,
                approved_by = :actor, decision_comment = :comment,
                updated_at = :updated_at, updated_by = :actor
            WHERE release_id = :release_id AND release_status = :expected
            """,
            {
                "status": status,
                "approved_at": now,
                "actor": actor,
                "comment": comment[:4000],
                "updated_at": now,
                "release_id": release_id,
                "expected": RELEASE_READY,
            },
        )
        updated = self.get_release(release_id)
        if updated["release_status"] != status:
            raise ConflictError("Release changed concurrently; refresh and try again.")
        self.audit(
            event_type="RELEASE_APPROVED" if approve else "RELEASE_REJECTED",
            entity_type="RELEASE",
            entity_id=release_id,
            project_id=release["project_id"],
            release_id=release_id,
            actor=actor,
            detail={"source_revision": release["source_revision"], "comment": comment},
        )
        return updated

    def authorize_production(
        self,
        release_id: str,
        *,
        repository_uri: str,
        source_revision: str,
        actor: str,
    ) -> dict[str, Any]:
        release = self.get_release(release_id)
        self._assert_release_identity(
            release,
            repository_uri=repository_uri,
            source_revision=source_revision,
        )
        if release["release_status"] != RELEASE_APPROVED:
            raise ConflictError("Release is not approved for production deployment.")
        if release["dev_deployment_status"] != DEV_DEPLOYED or not bool(release["dev_tag_check_passed"]):
            raise ConflictError("The exact revision has not passed dev deployment and tag validation.")
        stored_evaluation = self._stored_tag_evaluation(release, "dev")
        if not stored_evaluation.passed:
            raise ConflictError(
                "Stored dev tag evidence is incomplete or invalid; production authorization is denied: "
                + stored_evaluation.detail
            )
        now = utc_now()
        authorization_marker = generate_id("AUTH", 16)
        self.execute(
            f"""
            UPDATE {self.settings.table('releases')}
            SET release_status = :release_status,
                prod_deployment_status = :prod_status,
                deployment_message = :authorization_marker,
                updated_at = :updated_at, updated_by = :actor
            WHERE release_id = :release_id AND release_status = :expected
            """,
            {
                "release_status": RELEASE_DEPLOYING,
                "prod_status": PROD_DEPLOYING,
                "authorization_marker": authorization_marker,
                "updated_at": now,
                "actor": actor,
                "release_id": release_id,
                "expected": RELEASE_APPROVED,
            },
        )
        updated = self.get_release(release_id)
        if (
            updated["release_status"] != RELEASE_DEPLOYING
            or updated.get("deployment_message") != authorization_marker
        ):
            raise ConflictError("Production authorization was already consumed or release changed concurrently.")
        self.audit(
            event_type="PROD_DEPLOYMENT_AUTHORIZED",
            entity_type="RELEASE",
            entity_id=release_id,
            project_id=release["project_id"],
            release_id=release_id,
            actor=actor,
            detail={"source_revision": source_revision, "repository": release["repository_uri"]},
        )
        return updated

    def record_production_result(
        self,
        release_id: str,
        report: ProductionReport,
        actor: str,
    ) -> dict[str, Any]:
        release = self.get_release(release_id)
        rows = [item.model_dump(mode="json") for item in report.tag_results]
        tag_evaluation = evaluate_tag_evidence(
            rows,
            project_id=release["project_id"],
            environment="prod",
            settings=self.settings,
        )
        passed = all(
            (
                report.bundle_valid,
                report.deployment_succeeded,
                report.workload_succeeded,
                tag_evaluation.passed,
            )
        )

        # A retried report after an HTTP response was lost is safe and idempotent. It may not
        # rewrite terminal evidence or change the outcome.
        if release["release_status"] in {RELEASE_DEPLOYED, RELEASE_FAILED}:
            self._assert_release_identity(
                release,
                repository_uri=report.repository_uri,
                source_revision=report.source_revision,
                require_current_config=False,
            )
            stored = self._stored_tag_evaluation(release, "prod")
            expected_terminal = RELEASE_DEPLOYED if passed else RELEASE_FAILED
            if release["release_status"] == expected_terminal and stored.passed == tag_evaluation.passed:
                return release
            raise ConflictError("The saved production result does not match the terminal release outcome.")

        if release["release_status"] != RELEASE_DEPLOYING:
            raise ConflictError("Release is not in DEPLOYING state.")
        self._assert_release_identity(
            release,
            repository_uri=report.repository_uri,
            source_revision=report.source_revision,
        )

        release_status = RELEASE_DEPLOYED if passed else RELEASE_FAILED
        prod_status = PROD_DEPLOYED if passed else PROD_FAILED
        detail = " | ".join(item for item in (report.detail.strip(), tag_evaluation.detail) if item)
        message = (
            "Approved revision deployed to production and mandatory tags passed."
            if passed
            else "Production deployment, workload execution, or mandatory tag verification failed."
        )
        now = utc_now()

        # Claim final reporting without adding another table or worker lease. The authorization
        # marker is compare-and-swapped to a completion marker; only the winner may replace
        # evidence and close the release.
        previous_marker = str(release.get("deployment_message") or "")
        completion_marker = generate_id("COMP", 16)
        self.execute(
            f"""
            UPDATE {self.settings.table('releases')}
            SET deployment_message = :completion_marker,
                updated_at = :updated_at, updated_by = :actor
            WHERE release_id = :release_id
              AND release_status = :expected_status
              AND deployment_message = :previous_marker
            """,
            {
                "completion_marker": completion_marker,
                "updated_at": now,
                "actor": actor,
                "release_id": release_id,
                "expected_status": RELEASE_DEPLOYING,
                "previous_marker": previous_marker,
            },
        )
        claimed = self.get_release(release_id)
        if (
            claimed["release_status"] != RELEASE_DEPLOYING
            or str(claimed.get("deployment_message") or "") != completion_marker
        ):
            raise ConflictError("Production result reporting was already claimed or the release changed.")

        self._replace_tag_results(release_id, release["project_id"], "prod", rows, actor)
        self.execute(
            f"""
            UPDATE {self.settings.table('releases')}
            SET release_status = :release_status,
                prod_deployment_status = :prod_status,
                prod_tag_check_passed = :tag_passed,
                prod_tag_check_detail = :detail,
                prod_pipeline_run_url = :run_url,
                prod_deployed_at = :deployed_at,
                deployment_message = :message,
                updated_at = :updated_at, updated_by = :actor
            WHERE release_id = :release_id
              AND release_status = :expected_status
              AND deployment_message = :completion_marker
            """,
            {
                "release_status": release_status,
                "prod_status": prod_status,
                "tag_passed": tag_evaluation.passed,
                "detail": detail[:12000],
                "run_url": report.run_url,
                "deployed_at": now,
                "message": message,
                "updated_at": now,
                "actor": actor,
                "release_id": release_id,
                "expected_status": RELEASE_DEPLOYING,
                "completion_marker": completion_marker,
            },
        )
        updated = self.get_release(release_id)
        if updated["release_status"] != release_status or updated.get("deployment_message") != message:
            raise ConflictError("Release changed concurrently while the production result was recorded.")
        self.audit(
            event_type="PROD_DEPLOYED" if passed else "PROD_DEPLOY_FAILED",
            entity_type="RELEASE",
            entity_id=release_id,
            project_id=release["project_id"],
            release_id=release_id,
            actor=actor,
            detail={"detail": detail, "run_url": report.run_url, "message": message},
        )
        return updated

    def mark_production_failed(self, release_id: str, actor: str, comment: str) -> dict[str, Any]:
        """Close a release left in DEPLOYING after a production CI interruption."""
        release = self.get_release(release_id)
        if release["release_status"] != RELEASE_DEPLOYING:
            raise ConflictError("Only a release in DEPLOYING state can be marked failed.")
        now = utc_now()
        detail = comment.strip()[:4000]
        previous_marker = str(release.get("deployment_message") or "")
        message = "Production deployment closed by an administrator after CI interruption."
        self.execute(
            f"""
            UPDATE {self.settings.table('releases')}
            SET release_status = :release_status,
                prod_deployment_status = :prod_status,
                prod_tag_check_passed = false,
                prod_tag_check_detail = :detail,
                prod_deployed_at = :completed_at,
                deployment_message = :message,
                updated_at = :updated_at, updated_by = :actor
            WHERE release_id = :release_id
              AND release_status = :expected_status
              AND deployment_message = :previous_marker
            """,
            {
                "release_status": RELEASE_FAILED,
                "prod_status": PROD_FAILED,
                "detail": detail,
                "completed_at": now,
                "message": message,
                "updated_at": now,
                "actor": actor,
                "release_id": release_id,
                "expected_status": RELEASE_DEPLOYING,
                "previous_marker": previous_marker,
            },
        )
        updated = self.get_release(release_id)
        if updated["release_status"] != RELEASE_FAILED or updated.get("deployment_message") != message:
            raise ConflictError("Release changed concurrently; refresh and try again.")
        self.audit(
            event_type="PROD_DEPLOYMENT_ABORTED",
            entity_type="RELEASE",
            entity_id=release_id,
            project_id=release["project_id"],
            release_id=release_id,
            actor=actor,
            detail={"comment": detail},
        )
        return updated

    # Evidence and dashboards --------------------------------------------------
    def list_resource_tags(self, release_id: str | None = None, limit: int = 2000) -> list[dict[str, Any]]:
        if release_id:
            return self.fetch_all(
                f"""
                SELECT * FROM {self.settings.table('resource_tags')}
                WHERE release_id = :release_id
                ORDER BY environment, resource_type, logical_name, tag_key
                """,
                {"release_id": release_id},
            )
        return self.fetch_all(
            f"SELECT * FROM {self.settings.table('resource_tags')} ORDER BY checked_at DESC LIMIT {int(limit)}"
        )

    def list_audit(self, limit: int = 500) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"SELECT * FROM {self.settings.table('audit')} ORDER BY created_at DESC LIMIT {int(limit)}"
        )

    def dashboard(self) -> dict[str, Any]:
        project_counts = {
            str(row["status"]): int(row["count"])
            for row in self.fetch_all(
                f"SELECT lifecycle_status AS status, count(*) AS count "
                f"FROM {self.settings.table('projects')} GROUP BY lifecycle_status"
            )
        }
        release_counts = {
            str(row["status"]): int(row["count"])
            for row in self.fetch_all(
                f"SELECT release_status AS status, count(*) AS count "
                f"FROM {self.settings.table('releases')} GROUP BY release_status"
            )
        }
        return {
            "active_projects": project_counts.get(PROJECT_ACTIVE, 0),
            "pending_projects": project_counts.get(PROJECT_PENDING, 0),
            "ready_releases": release_counts.get(RELEASE_READY, 0),
            "failed_releases": release_counts.get(RELEASE_CHECKS_FAILED, 0)
            + release_counts.get(RELEASE_FAILED, 0),
            "deployed_releases": release_counts.get(RELEASE_DEPLOYED, 0),
            "project_counts": project_counts,
            "release_counts": release_counts,
        }
