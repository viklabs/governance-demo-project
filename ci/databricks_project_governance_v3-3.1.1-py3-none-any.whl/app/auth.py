from __future__ import annotations

import os
from dataclasses import dataclass
from urllib.parse import urlparse

from fastapi import HTTPException, Request, status

from app.governance import AuthorizationError
from app.settings import Settings


@dataclass(frozen=True)
class Actor:
    normalized: str
    display_name: str = ""


def actor_from_request(request: Request, settings: Settings) -> Actor:
    """Return the identity authenticated by the Databricks Apps gateway.

    Databricks Apps forwards the signed-in user or service-principal identity. A deliberately
    explicit local fallback is available only when enabled in configuration.
    """

    email = (request.headers.get("x-forwarded-email") or "").strip().lower()
    preferred = (request.headers.get("x-forwarded-preferred-username") or "").strip().lower()
    user = (request.headers.get("x-forwarded-user") or "").strip().lower()
    display = (request.headers.get("x-forwarded-name") or "").strip()
    value = email or preferred or user
    if value:
        return Actor(normalized=value, display_name=display or value)

    if settings.allow_local_development:
        local = os.getenv(settings.local_user_env, "").strip().lower()
        explicit = request.headers.get("x-local-user", "").strip().lower()
        value = explicit or local
        if value:
            return Actor(normalized=value, display_name=value)

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=(
            "Signed-in identity is unavailable. Run behind Databricks Apps authentication or "
            "enable the explicit local-development fallback."
        ),
    )


def _same_origin(request: Request) -> None:
    expected_host = (
        request.headers.get("x-forwarded-host") or request.headers.get("host") or ""
    ).split(",", 1)[0].strip().lower()
    origin = request.headers.get("origin", "").strip()
    referer = request.headers.get("referer", "").strip()
    sec_fetch_site = request.headers.get("sec-fetch-site", "").strip().lower()

    source = origin or referer
    source_host = urlparse(source).netloc.lower() if source else ""
    if source_host and source_host != expected_host:
        raise HTTPException(status_code=403, detail="Cross-site browser request was rejected.")
    if sec_fetch_site and sec_fetch_site not in {"same-origin", "same-site", "none"}:
        raise HTTPException(status_code=403, detail="Cross-site browser request was rejected.")
    if not source and not sec_fetch_site:
        raise HTTPException(
            status_code=403,
            detail="Browser mutation request is missing same-origin metadata.",
        )


def require_mutation_request(request: Request) -> None:
    """Require an explicit UI or CI mutation marker.

    UI calls also require same-origin browser metadata. CI calls are protected by the Databricks
    App OAuth gateway and application authorization. CORS middleware is intentionally not enabled.
    """

    marker = request.headers.get("x-governance-request", "").strip().lower()
    if marker not in {"ui", "ci"}:
        raise HTTPException(
            status_code=403,
            detail="Mutation requests must set X-Governance-Request to ui or ci.",
        )
    settings: Settings = request.app.state.settings
    if marker == "ui":
        if settings.allow_local_development and not request.headers.get(
            "x-forwarded-host"
        ):
            return
        _same_origin(request)


class Authorization:
    def __init__(self, settings: Settings):
        self.settings = settings

    def is_admin(self, actor: Actor) -> bool:
        return actor.normalized in self.settings.admin_principals

    def is_approver(self, actor: Actor) -> bool:
        return self.is_admin(actor) or actor.normalized in self.settings.approver_principals

    def is_production_deployer(self, actor: Actor) -> bool:
        return (
            actor.normalized in self.settings.production_deployer_principals
            or (self.settings.allow_admin_as_production_deployer and self.is_admin(actor))
        )

    def require_admin(self, actor: Actor) -> None:
        if not self.is_admin(actor):
            raise AuthorizationError("Administrator permission is required.")

    def require_approver(self, actor: Actor) -> None:
        if not self.is_approver(actor):
            raise AuthorizationError("Approver permission is required.")

    def require_production_deployer(self, actor: Actor) -> None:
        if not self.is_production_deployer(actor):
            raise AuthorizationError("Production deployer permission is required.")

    def require_project_manager(self, project: dict[str, object], actor: Actor) -> None:
        owners = {
            str(project.get("technical_owner_email") or "").strip().lower(),
            str(project.get("business_owner_email") or "").strip().lower(),
        }
        if not self.is_admin(actor) and actor.normalized not in owners:
            raise AuthorizationError("Project owner or administrator permission is required.")

    def require_ci_submitter(self, project: dict[str, object], actor: Actor) -> None:
        """Require an explicitly registered dev CI identity.

        Project owners may create releases, but only administrators can change delivery
        configuration or the authorized CI list. Dev validation evidence is accepted only from an
        actor deliberately listed in authorized_submitters. Administrators retain break-glass
        access for setup and troubleshooting.
        """

        if self.is_admin(actor):
            return
        submitters = {
            str(item).strip().lower()
            for item in (project.get("authorized_submitters") or ())
            if str(item).strip()
        }
        if actor.normalized not in submitters:
            raise AuthorizationError(
                "This identity is not registered as a development CI submitter for the project."
            )
